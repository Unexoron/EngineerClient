export function prefix(message) {
    ChatLib.chat("&6[&4Engineer&8Client&6]&r " + message)
}

export function space() {
    ChatLib.chat("")
}

export function divider() {
    ChatLib.chat(ChatLib.getChatBreak("-"))
}