/// <reference types="../CTAutocomplete" />

//NEW

import { @Vigilant, @TextProperty, @ButtonProperty, @SwitchProperty, @ColorProperty, @DecimalSliderProperty, Color, @SelectorProperty } from "../Vigilance";

@Vigilant("EngineerClient", "EngineerClient", {
    getCategoryComparator: () => (a, b) => {
        const categories = ["Auto Croesus","Chat Cleaner", "General", "Party Commands", "Clear", "Action Bar", "Splits", "Boss", "Terminals"];
        return categories.indexOf(a.name) - categories.indexOf(b.name);
    }
})

class config {
    scorecalcgui = new Gui()
    witherspeedgui = new Gui()

    speeddisplaygui = new Gui()
    healthgui = new Gui()
    managui = new Gui()
    overflowgui = new Gui()
    manausagegui = new Gui()
    secretsgui = new Gui()

    bosssplitsgui = new Gui()
    clearsplitsgui = new Gui()
    purplepadtimergui = new Gui()
	runpredictiongui = new Gui()
	runpredictiongui = new Gui()

    p3gui = new Gui()
    sectiontimesgui = new Gui()
    ticktimergui = new Gui()
    eelocationgui = new Gui()
	

    p1gui = new Gui()
	crystalgui = new Gui()
    p2gui = new Gui()
    stormcountdowngui = new Gui()
    p4gui = new Gui()



	/// AUTO CROESUS ///

	
	@SwitchProperty({
		name: "Toggle Auto Croesus",
		category: "Croesus",
	})
	croesustoggle = false;

	@SwitchProperty({
		name: "Auto Drop/Sell",
		description: "Drops/sells items after all chests have been claimed",
		category: "Croesus",
	})
	autosell = false;

	@DecimalSliderProperty({
		name: "Inventory slot that will never have anything important in it",
		description: "auto sell will drop anything in this slot\n1 being top left of inventory",
		category: "Croesus",
		minF: 1,
		maxF: 34,
		decimalPlaces: 0
	})
	inventoryslot = 26;



	//// CLEAR ////

	@SwitchProperty({
		name: "Toggle score calc",
		subcategory: "Action Bar",
		category: "Clear",
	})
	togglescorecalc = false;

	@ButtonProperty({
        name: "Move Score Calc",
		subcategory: "Action Bar",
        category: "Clear",
        placeholder: "Move"
    })
    MoveScoreCalcGui() {
        this.scorecalcgui.open()
    };





	//// CHAT CLEANER ////

	@SwitchProperty({
		name: "Chat cleaner",
		description: "Hides a LOT of useless messages",
		category: "Chat Cleaner",
	})
	chatcleaner = false;

	@SwitchProperty({
		name: "clean friend join messages",
		category: "Chat Cleaner",
	})
	cleanfriendjoin = false;

	@SwitchProperty({
		name: "clean party chat messages",
		category: "Chat Cleaner",
	})
	cleanpartychat = false;


	//// GENERAL ////

	@ButtonProperty({
        name: "Speed gui",
        category: "General",
        placeholder: "Move"
    })
    MoveSpeedDisplayGui() {
        this.speeddisplaygui.open()
    };


	@SwitchProperty({
		name: "Tac Timer",
		description: "Tick accurate",
		category: "General",
	})
	tactimer = false;

	@SwitchProperty({
		name: "Full Ender Pearl Message",
		category: "General",
		subcategory: "Ender Pearl",
	})
	FullEnderPearlMsg = false;

	@SwitchProperty({
		name: "no leak line",
		description: "Tick accurate",
		category: "General",
	})
	noleakline = false;

	@SwitchProperty({
		name: "Tac Timer Outside Dungeons",
		category: "General",
	})
	tacoutside = false;

	@SwitchProperty({
		name: "Hide Experience Levels",
		category: "General",
	})
	hideexperiencelevels = false;

	@SwitchProperty({
		name: "Speed Display",
		description: "Hides speed if its 400 or 500",
		category: "General",
	})
	speeddisplay = false;

	@SwitchProperty({
		name: "Show 400 Speed",
		category: "General",
	})
	showbadspeed = false;

	@ButtonProperty({
        name: "Speed gui",
        category: "General",
        placeholder: "Move"
    })
    MoveSpeedDisplayGui() {
        this.speeddisplaygui.open()
    };

	// @SwitchProperty({
	// 	name: "Auto Find Stage 4 Lobbies",
	// 	category: "General",
	// 	subcategory: "End Stone Protector"
	// })
	// autolobbies = false;

	// @TextProperty({
	// 	name: "Auto Invite",
	// 	description: "Auto invites the set player and warps them",
	// 	category: "General",
	// 	subcategory: "End Stone Protector"
	// })
	// autoinviteset = "EngineerAndrew";









	//// Party Commands ////

	@SwitchProperty({
		name: "Party Commands Toggle",
		category: "Party Commands"
	})
	PartyCommandToggle = false;

	@SwitchProperty({
		name: "!Inv",
		description: "invites players",
		category: "Party Commands"
	})
	InvPartyCommand = false;

	@SwitchProperty({
		name: "!LSIW",
		description: "Sends Lowskillinvwalkers lyrics",
		category: "Party Commands"
	})
	LsiwPartyCommand = false;














	//// ACTION BAR ////

	@SwitchProperty({
		name: "Replace Action Bar",
		subcategory: "Action Bar",
		category: "Action Bar",
	})
	replaceactionbar = false;

	@SwitchProperty({
		name: "Hide Action Bar",
		subcategory: "Action Bar",
		category: "Action Bar",
	})
	hideactionbar = false;


	@SwitchProperty({
		name: "Health gui",
		description: "Toggles health gui",
		category: "Action Bar",
		subcategory: "Health",
	})
	healthguitoggle = false;

	@SwitchProperty({
		name: "Use health percent",
		category: "Action Bar",
		subcategory: "Health",
	})
	usehealthpercent = false;

	@SwitchProperty({
		name: "Use health icon",
		category: "Action Bar",
		subcategory: "Health",
	})
	usehealthicon = false;

	@SwitchProperty({
		name: "Only show health icon",
		category: "Action Bar",
		subcategory: "Health",
	})
	onlyshowhealthicon = false;

	@SwitchProperty({
		name: "Change health colors",
		description: "gold: >100  pink: 100-85  red: 85-50  dark red: 50-20  black: 20-0",
		category: "Action Bar",
		subcategory: "Health",
	})
	changehealthcolors = false;

	@SwitchProperty({
		name: "Only show color for absorption",
		category: "Action Bar",
		subcategory: "Health",
	})
	onlyshowcolorforabsorption = false;

	@SwitchProperty({
		name: "Use pink for 100-85",
		category: "Action Bar",
		subcategory: "Health",
	})
	usepinkforpercent = false;

	@DecimalSliderProperty({
		name: "Only start showing when health is less than certain percent (use 101 to always show)",
		category: "Action Bar",
		subcategory: "Health",
		minF: 30,
		maxF: 101,
		decimalPlaces: 0
	})
	healthpercenttoshow = 90;

	@ButtonProperty({
        name: "Move Health Gui",
        category: "Action Bar",
		subcategory: "Health",
        placeholder: "Move"
    })
    MoveHealthGui() {
        this.healthgui.open()
    };/////////////////////ignore this
//////////////filling space to make it 
////////////////look better on minimap
	@SwitchProperty({
		name: "Mana gui",
		description: "Toggles mana gui",
		category: "Action Bar",
		subcategory: "Mana",
	})
	managuitoggle = false;
	
	@SwitchProperty({
		name: "Use mana percent",
		category: "Action Bar",
		subcategory: "Mana",
	})
	usemanapercent = false;

	@SwitchProperty({
		name: "Use mana icon",
		category: "Action Bar",
		subcategory: "Mana",
	})
	usemanaicon = false;

	@SwitchProperty({
		name: "Use less ugly icon",
		category: "Action Bar",
		subcategory: "Mana",
	})
	uselessuglymanaicon = false;

	@SwitchProperty({
		name: "Only show mana icon",
		category: "Action Bar",
		subcategory: "Mana",
	})
	onlyshowmanaicon = false;

	@SwitchProperty({
		name: "Change mana colors",
		description: "light blue: 100-60  blue: 60-30  dark blue: 30-0",
		category: "Action Bar",
		subcategory: "Mana",
	})
	changemanacolors = false;

	@DecimalSliderProperty({
		name: "Only start showing when mana is less than certain percent (use 101 to always show)",
		category: "Action Bar",
		subcategory: "Mana",
		minF: 30,
		maxF: 101,
		decimalPlaces: 0
	})
	manapercenttoshow = 90;

	@ButtonProperty({
        name: "Move Mana Gui",
        category: "Action Bar",
		subcategory: "Mana",
        placeholder: "Move"
    })
    MoveManaGui() {
        this.managui.open()
    };


	@SwitchProperty({
		name: "Overflow mana gui",
		description: "Toggles overflow mana gui",
		category: "Action Bar",
		subcategory: "Overflow Mana",
	})
	overflowguitoggle = false;

	@ButtonProperty({
        name: "Move Overflow Mana Gui",
        category: "Action Bar",
		subcategory: "Overflow Mana",
        placeholder: "Move"
    })
    MoveOverflowGui() {
        this.overflowgui.open()
    };


	@SwitchProperty({
		name: "Mana usage gui",
		description: "Toggles mana usage gui",
		category: "Action Bar",
		subcategory: "Mana Usage",
	})
	manausageguitoggle = false;

	@ButtonProperty({
        name: "Move Mana Usage Gui",
        category: "Action Bar",
		subcategory: "Mana Usage",
        placeholder: "Move"
    })
    MoveManaUsageGui() {
        this.manausagegui.open()
    };


	@SwitchProperty({
		name: "Secrets gui",
		description: "Toggles secrets gui",
		category: "Action Bar",
		subcategory: "Secrets",
	})
	secretsguitoggle = false;

	@SwitchProperty({
		name: "Secrets title",
		description: "Shows \"secrets\" above secret count",
		category: "Action Bar",
		subcategory: "Secrets",
	})
	secretstitle = false;

	@ButtonProperty({
        name: "Move Secrets Gui",
        category: "Action Bar",
		subcategory: "Secrets",
        placeholder: "Move"
    })
    MoveSecretsGui() {
        this.secretsgui.open()
    };























	//// SPLITS ////

	@SwitchProperty({
		name: "Clear Splits",
		description: "Not tick accurate :(",
		category: "Splits",
		subcategory: "Clear Splits",
	})
	clearsplits = false;

	@SwitchProperty({
		name: "Blood Checkmark",
		description: "Shows checkmark next to blood split when all mobs have spawned",
		category: "Splits",
		subcategory: "Clear Splits",
	})
	bloodcheckmark = false;

	@ButtonProperty({
        name: "Move Clear Splits",
        category: "Splits",
		subcategory: "Clear Splits",
        placeholder: "Move"
    })
    MoveClearSplitsGui() {
        this.clearsplitsgui.open()
    };

	@SwitchProperty({
		name: "Toggle Clear Split Names",
		description: "Shows names of clear splits (really ugly)",
		category: "Splits",
		subcategory: "Clear Splits",
	})
	namedclearsplits = false;




	@SwitchProperty({
		name: "Boss Splits",
		description: "Tick accurate Boss splits",
		category: "Splits",
		subcategory: "Boss splits",
	})
	bosssplits = false;

	@ButtonProperty({
        name: "Move Boss Splits",
        category: "Splits",
		subcategory: "Boss splits",
        placeholder: "Move"
    })
    MoveBossSplitsGui() {
        this.bosssplitsgui.open()
    };

	@SwitchProperty({
		name: "Purple Pad Timer",
		description: "Adds tick accurate timer for purple pad",
		category: "Splits",
		subcategory: "Boss splits",
	})
	purplepadtimer = false;

	@ButtonProperty({
        name: "Move Purple Pad Timer",
        category: "Splits",
		subcategory: "Boss splits",
        placeholder: "Move"
    })
    MovePurplePadTimerGui() {
        this.purplepadtimergui.open()
    };

	@SwitchProperty({
		name: "Toggle Boss Split Names",
		description: "Shows names of splits (really ugly)",
		category: "Splits",
		subcategory: "Boss splits",
	})
	namedbosssplits = false;



	@SwitchProperty({
		name: "Run Prediction",
		description: "Predicts run time and shows how much time you lost/gained on each split based off of preset times",
		category: "Splits",
		subcategory: "Run Prediction",
	})
	runprediction = false;

	@SwitchProperty({
		name: "Run Prediction Split Name",
		description: "Shows 'Run Prediction' before the run prediction",
		category: "Splits",
		subcategory: "Run Prediction",
	})
	runpredictionlongname = false;	

	@ButtonProperty({
        name: "Move Run Prediction Gui",
        category: "Splits",
		subcategory: "Run Prediction",
        placeholder: "Move"
    })
    MoveRunPredictionGui() {
        this.runpredictiongui.open()
    };

	@SwitchProperty({
		name: "Remove Brackets",
		category: "Splits",
		subcategory: "Run Prediction",
	})
	removebrackets = false;	

	@SwitchProperty({
		name: "Only show how much time you lost/gained",
		category: "Splits",
		subcategory: "Run Prediction",
	})
	onlytimelostgained = false;	
	
	// @SwitchProperty({
    //     name: "Update Total Run Time",
	// 	description: `${parseFloat(Settings.rushtimeforprediction) + parseFloat(Settings.camptimeforprediction) + parseFloat(Settings.portaltimeforprediction) + parseFloat(Settings.maxortimeforprediction) + parseFloat(Settings.stormtimeforprediction) + parseFloat(Settings.terminalstimeforprediction) + parseFloat(Settings.goldortimeforprediction) + parseFloat(Settings.necrontimeforprediction) + parseFloat(Settings.animationtimeforprediction)}`,
	// 	subcategory: "Run Prediction",
    //     category: "Splits",
    //     placeholder: "test"
    // })
	// updatetotalruntime = false;

	@TextProperty({
		name: "Blood Rush Time",
		category: "Splits",
		subcategory: "Run Prediction"
	})
	rushtimeforprediction = "15.3";
	
	@TextProperty({
		name: "Camp Time",
		category: "Splits",
		subcategory: "Run Prediction"
	})
	camptimeforprediction = "62.8";
	
	@TextProperty({
		name: "Portal Time",
		category: "Splits",
		subcategory: "Run Prediction"
	})
	portaltimeforprediction = "4.2";
	
	@TextProperty({
		name: "Maxor Time",
		category: "Splits",
		subcategory: "Run Prediction"
	})
	maxortimeforprediction = "26.3";
	
	@TextProperty({
		name: "Storm Time",
		category: "Splits",
		subcategory: "Run Prediction"
	})
	stormtimeforprediction = "47.2";
	
	@TextProperty({
		name: "Terminals Time",
		category: "Splits",
		subcategory: "Run Prediction"
	})
	terminalstimeforprediction = "42.2";
	
	@TextProperty({
		name: "Goldor Time",
		category: "Splits",
		subcategory: "Run Prediction"
	})
	goldortimeforprediction = "7.2";
	
	@TextProperty({
		name: "Necron Time",
		category: "Splits",
		subcategory: "Run Prediction"
	})
	necrontimeforprediction = "30.3";
	
	@TextProperty({
		name: "Animation Time",
		category: "Splits",
		subcategory: "Run Prediction"
	})
	animationtimeforprediction = "4.2";






















	//// P3 ////

	@SwitchProperty({
		name: "Terminals Info",
		description: "Adds gui with info on p3",
		category: "Terminals",
        subcategory: "Terminal gui",
	})
	p3info = false;

	@SwitchProperty({
		name: "Simple Terminal Progress",
		description: "Changes the terminal info gui to only display progress",
		category: "Terminals",
        subcategory: "Terminal gui",
	})
	p3infosimple = false;

	@ButtonProperty({
        name: "Move Terminals Gui",
        category: "Terminals",
        subcategory: "Terminal gui",
        placeholder: "Move"
    })
    MoveP3Gui() {
        this.p3gui.open()
    };

	@SwitchProperty({
		name: "Section Times",
		description: "Shows how long a section took",
		category: "Terminals",
        subcategory: "Terminal gui",
	})
	sectiontimes = false;

	@ButtonProperty({
        name: "Move Section Times Gui",
        category: "Terminals",
        subcategory: "Terminal gui",
        placeholder: "Move"
    })
    MoveSectionTimesGui() {
        this.sectiontimesgui.open()
    };

	@SwitchProperty({
		name: "Early Enter Alert",
		description: "Alerts you when someone is at an early enter location using player position\nWill only work if you are within 4 chunks of the ee location",
		category: "Terminals",
        subcategory: "Early Enter Alerts"
	})
	eetitles = false;

	@ButtonProperty({
        name: "Move EE Location Gui",
		category: "Terminals",
        subcategory: "Early Enter Alerts",
        placeholder: "Move"
    })
    MoveEELocationsGui() {
        this.eelocationgui.open()
    };

	@SwitchProperty({
		name: "Paste early enters into party chat",
		category: "Terminals",
		subcategory: "Early Enter Alerts",
	})
	sendchatmessage = true;

	@SwitchProperty({
		name: "Core Timestamps",
		description: "Paste how long each party member took to get into core",
		category: "Boss",
		subcategory: "Core",
	})
	coremsg = true;

	@SwitchProperty({
		name: "Hide Players with 0s core enter times",
		description: "If somone was in core before 4th section ended, they wont be included in the msg",
		category: "Boss",
		subcategory: "Core",
	})
	preincoremsg = true;


	@TextProperty({
		name: "Core Message if already in",
		description: "changes the message for if someone is in core before 4th section ends",
		category: "Boss",
		subcategory: "Core",
	})
	coremsgtext = "took 0s";
















	//// BOSS //// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 
	// ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ ⚠ 

	@SwitchProperty({
		name: "Wither Boss Highlight",
		description: "WORK IN PROGRESS DISABLE FOR NOW | Shows where the withers will be in 1 tick",
		category: "Boss",
	})
	witherbox = false;

	@SwitchProperty({
		name: "Wither Movement Speed Display",
		description: "WORK IN PROGRESS DISABLE FOR NOW | Displays how fast the withers are moving in blocks/sec",
		category: "Boss",
	})
	witherspeed = false;

	@SwitchProperty({
		name: "Wither movement speed include y level",
		description: "Include vertical motion in speed",
		category: "Boss",
	})
	witherspeedy = false;

	@ButtonProperty({
        name: "Move Wither Movement Speed Gui",
        category: "Boss",
        placeholder: "Move"
    })
    MoveWitherSpeedcGui() {
        this.witherspeedgui.open()
    };

	// Maxor //

	@SwitchProperty({
		name: "Maxor Info",
		description: "WORK IN PROGRESS DISABLE FOR NOW | Adds gui with info on p1",
		category: "Boss",
        subcategory: "Maxor",
	})
	p1info = false;

	@ButtonProperty({
        name: "Move Maxor Gui",
        category: "Boss",
        subcategory: "Maxor",
        placeholder: "Move"
    })
    MoveP1Gui() {
        this.p1gui.open()
    };

	@SwitchProperty({
		name: "Crystal Gui",
		description: "WORK IN PROGRESS DISABLE FOR NOW | Shows how long a cystal took",
		category: "Boss",
        subcategory: "Maxor",
	})
	asnvuiwb9ugbeeebgiwebg = false;

	@ButtonProperty({
        name: "Move Crystal Gui",
        category: "Boss",
        subcategory: "Maxor",
        placeholder: "Move"
    })
    MoveCrystalGui() {
        this.crystalgui.open()
    };

	// Storm //

	@SwitchProperty({
		name: "Storm Info",
		description: "Adds gui with info on p2",
		category: "Boss",
        subcategory: "Storm",
	})
	p2info = false;

	@SwitchProperty({
		name: "Detailed Names",
		description: "Adds names to each split in the storm info",
		category: "Boss",
        subcategory: "Storm",
	})
	p2names = false;

	@ButtonProperty({
        name: "Move Storm Gui",
        category: "Boss",
        subcategory: "Storm",
        placeholder: "Move"
    })
    MoveP2Gui() {
        this.p2gui.open()
    };

	@SwitchProperty({
		name: "Storm Lightning Countdown",
		description: "Shows how long until storm lightning",
		category: "Boss",
        subcategory: "Storm",
	})
	stormcountdown = false;

	@ButtonProperty({
        name: "Move Storm Countdown Gui",
        category: "Boss",
        subcategory: "Storm",
        placeholder: "Move"
    })
    MoveStormCountdownGui() {
        this.stormcountdowngui.open()
    };

	@SwitchProperty({
		name: "Necron Info",
		description: "WORK IN PROGRESS DISABLE FOR NOW | Adds gui with info on p4",
		category: "Boss",
        subcategory: "Necron",
	})
	p4info = false;
	









    constructor() {//   
        this.initialize(this);
		this.addDependency("Speed gui", "Speed Display")
		this.addDependency("Show 400 Speed", "Speed Display")
		this.addDependency("Tac Timer Outside Dungeons", "Tac Timer")
		this.addDependency("Move Score Calc", "Toggle score calc")
		// this.addDependency("Auto Invite", "Auto Find Stage 4 Lobbies")

		this.addDependency("!LSIW", "Party Commands Toggle")
		this.addDependency("!Inv", "Party Commands Toggle")

		this.addDependency("Hide Action Bar", "Replace Action Bar")
		this.addDependency("Use health percent", "Health gui")
		this.addDependency("Use health icon", "Health gui")
		this.addDependency("Only show health icon", "Health gui")
		this.addDependency("Change health colors", "Health gui")
		this.addDependency("Use pink for 100-85", "Health gui")
		this.addDependency("Only show color for absorption", "Health gui")
		this.addDependency("Only start showing when health is less than certain percent (use 101 to always show)", "Health gui")
		this.addDependency("Move Health Gui", "Health gui")
		this.addDependency("Only start showing when mana is less than certain percent (use 101 to always show)", "Mana gui")
		this.addDependency("Use mana percent", "Mana gui")
		this.addDependency("Use mana icon", "Mana gui")
		this.addDependency("Use less ugly icon", "Mana gui")
		this.addDependency("Only show mana icon", "Mana gui")
		this.addDependency("Change mana colors", "Mana gui")
		this.addDependency("Move Mana Gui", "Mana gui")
		this.addDependency("Move Overflow Mana Gui", "Overflow mana gui")
		this.addDependency("Move Mana Usage Gui", "Mana usage gui")
		this.addDependency("Secrets title", "Secrets gui")
		this.addDependency("Move Secrets Gui", "Secrets gui")

		this.addDependency("Blood Checkmark", "Clear Splits")
		this.addDependency("Move Clear Splits", "Clear Splits")
		this.addDependency("Toggle Clear Split Names", "Clear Splits")
		this.addDependency("Toggle Boss Split Names", "Boss Splits")
		this.addDependency("Move Boss Splits", "Boss Splits")
		this.addDependency("Move Purple Pad Timer", "Purple Pad Timer")
		this.addDependency("Wither movement speed include y level", "Wither Movement Speed Display")
		this.addDependency("Move Wither Movement Speed Gui", "Wither Movement Speed Display")
		this.addDependency("Hide Players with 0s core enter times", "Core Timestamps")
		this.addDependency("Core Message if already in", "Core Timestamps")
		this.addDependency("Run Prediction Split Name", "Run Prediction")
		this.addDependency("Remove Brackets", "Run Prediction")
		this.addDependency("Only show how much time you lost/gained", "Run Prediction")
		this.addDependency("Move Run Prediction Gui", "Run Prediction")
		// this.addDependency("Total Run Time", "Run Prediction")
		this.addDependency("Blood Rush Time", "Run Prediction")
		this.addDependency("Camp Time", "Run Prediction")
		this.addDependency("Portal Time", "Run Prediction")
		this.addDependency("Maxor Time", "Run Prediction")
		this.addDependency("Storm Time", "Run Prediction")
		this.addDependency("Terminals Time", "Run Prediction")
		this.addDependency("Goldor Time", "Run Prediction")
		this.addDependency("Necron Time", "Run Prediction")
		this.addDependency("Animation Time", "Run Prediction")

		this.addDependency("Move Storm Gui", "Storm Info")
		this.addDependency("Detailed Names", "Storm Info")
		this.addDependency("Move Storm Countdown Gui", "Storm Lightning Countdown")

		this.addDependency("Move Terminals Gui", "Terminals Info")
		this.addDependency("Simple Terminal Progress", "Terminals Info")
		this.addDependency("Move Section Times Gui", "Section Times")

		this.addDependency("Paste early enters into party chat", "Early Enter Alert")

		this.addDependency("Move EE Location Gui", "Early Enter Alert")
    }
}

export default new config()