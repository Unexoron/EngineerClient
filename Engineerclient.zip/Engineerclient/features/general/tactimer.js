import Settings from "../../config"

const overlay1 = { render: null, title: null, totaltime: null, started: null };

const overlayregister1 = register("renderOverlay", () => {
    if (!Settings.tactimer) return;
    if (((Date.now() - overlay1.started)) > overlay1.totaltime) {
        overlay1.render = false
        overlay1.unregister()
        return;
    }
	const [x, y, scale] = [0.487, 0.55, 2];
	Renderer.scale(scale);
	Renderer.drawStringWithShadow('&3' + ((Math.abs((Date.now()-2900) - overlay1.started )/1000).toFixed(1)), x * Renderer.screen.getWidth() / scale, y * Renderer.screen.getHeight() / scale);
}).unregister();

register('tick', () => {
    if (overlay1.render) overlayregister1.register()
});


register(`soundPlay`, () => {
    const item = Player.getHeldItem();
    if(!item.getName().includes('Tactical Insertion')) return
    overlay1.totaltime = 2900
    overlay1.render = true
    overlay1.started = Date.now();
}).setCriteria("fire.ignite")



register("worldUnload", () => {
    overlayregister1.unregister()
    overlay1.render = false
})

