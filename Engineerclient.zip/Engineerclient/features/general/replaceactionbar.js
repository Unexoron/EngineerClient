import Settings from "../../config"




////////////////////// rendering
import { data } from "../../utils/data"
const overlay1 = {render: null, title: `healthgui`};
const overlay2 = {render: null, title: `managui`};
const overlay3 = {render: null, title: `overflowgui`};
const overlay4 = {render: null, title: `manausagegui`};
const overlay5 = {render: null, title: `secretsgui`};
const overlayregister1 = register("renderOverlay", () => {
    if (!Settings.replaceactionbar || !Settings.healthguitoggle) return
    Renderer.scale(data.healthguidata.scale);Renderer.drawStringWithShadow((overlay1.title),data.healthguidata.x, data.healthguidata.y)}).unregister();
const overlayregister2 = register("renderOverlay", () => {
    if (!Settings.replaceactionbar || !Settings.managuitoggle) return
    Renderer.scale(data.managuidata.scale);Renderer.drawStringWithShadow((overlay2.title),data.managuidata.x, data.managuidata.y)}).unregister();
const overlayregister3 = register("renderOverlay", () => {
    if (!Settings.replaceactionbar || !Settings.overflowguitoggle) return
    Renderer.scale(data.overflowguidata.scale);Renderer.drawStringWithShadow((overlay3.title),data.overflowguidata.x, data.overflowguidata.y)}).unregister();
const overlayregister4 = register("renderOverlay", () => {
    if (!Settings.replaceactionbar || !Settings.manausageguitoggle) return
    Renderer.scale(data.manausageguidata.scale);Renderer.drawStringWithShadow((overlay4.title),data.manausageguidata.x, data.manausageguidata.y)}).unregister();
const overlayregister5 = register("renderOverlay", () => {
    if (!Settings.replaceactionbar || !Settings.secretsguitoggle) return
    Renderer.scale(data.secretsguidata.scale);Renderer.drawStringWithShadow((overlay5.title),data.secretsguidata.x, data.secretsguidata.y)}).unregister();
let gui1on; let gui2on; let gui3on; let gui4on; let gui5on 
let testtitle1 = [`&c2175/2175❤ `];let testtitle2 = [`&b2,461/2,461✎`];let testtitle3 = [`&3600ʬ`];let testtitle4 = [`&b-90 Mana (&6Ether Transmission&b)`];let testtitle5 = [`test`]
register('tick', () => {
    if (Settings.healthgui.isOpen()) {overlayregister1.register();overlay1.title = testtitle1;gui1on = true}
    if (!Settings.healthgui.isOpen() && gui1on) {overlayregister1.unregister();overlay1.title = " "; gui1on = false}
    if (overlay1.render) overlayregister1.register();
    if (Settings.managui.isOpen()) {overlayregister2.register();overlay2.title = testtitle2;gui2on = true}
    if (!Settings.managui.isOpen() && gui2on) {overlayregister2.unregister();overlay2.title = " "; gui2on = false}
    if (overlay2.render) overlayregister2.register();
    if (Settings.overflowgui.isOpen()) {overlayregister3.register();overlay3.title = testtitle3;gui3on = true}
    if (!Settings.overflowgui.isOpen() && gui3on) {overlayregister3.unregister();overlay3.title = " "; gui3on = false}
    if (overlay3.render) overlayregister3.register();
    if (Settings.manausagegui.isOpen()) {overlayregister4.register();overlay4.title = testtitle4;gui4on = true}
    if (!Settings.manausagegui.isOpen() && gui4on) {overlayregister4.unregister();overlay4.title = " "; gui4on = false}
    if (overlay4.render) overlayregister4.register();
    if (Settings.secretsgui.isOpen()) {overlayregister5.register();overlay5.title = testtitle5;gui5on = true}
    if (!Settings.secretsgui.isOpen() && gui5on) {overlayregister5.unregister();overlay5.title = " "; gui5on = false}
    if (overlay5.render) overlayregister5.register();
});register("dragged", (dx, dy, x, y, bn) => {
    if (Settings.healthgui.isOpen() && bn != 2){
        data.healthguidata.x = (x / data.healthguidata.scale); data.healthguidata.y = (y / data.healthguidata.scale);data.save()}
    if (Settings.managui.isOpen() && bn != 2){
        data.managuidata.x = (x / data.managuidata.scale); data.managuidata.y = (y / data.managuidata.scale);data.save()}
    if (Settings.overflowgui.isOpen() && bn != 2){
        data.overflowguidata.x = (x / data.overflowguidata.scale); data.overflowguidata.y = (y / data.overflowguidata.scale);data.save()}
    if (Settings.manausagegui.isOpen() && bn != 2){
        data.manausageguidata.x = (x / data.manausageguidata.scale); data.manausageguidata.y = (y / data.manausageguidata.scale);data.save()}
    if (Settings.secretsgui.isOpen() && bn != 2){
        data.secretsguidata.x = (x / data.secretsguidata.scale); data.secretsguidata.y = (y / data.secretsguidata.scale);data.save()}
});register("scrolled", (x, y, dir) => {
    if (Settings.healthgui.isOpen()){
        if (dir == 1) data.healthguidata.scale += 0.05; 
        else data.healthguidata.scale -= 0.05
        data.healthguidata.x = (x / data.healthguidata.scale); data.healthguidata.y = (y / data.healthguidata.scale);data.save()}
    if (Settings.managui.isOpen()){
        if (dir == 1) data.managuidata.scale += 0.05; 
        else data.managuidata.scale -= 0.05
        data.managuidata.x = (x / data.managuidata.scale); data.managuidata.y = (y / data.managuidata.scale);data.save()}
    if (Settings.overflowgui.isOpen()){
        if (dir == 1) data.overflowgui.scale += 0.05; 
        else data.overflowgui.scale -= 0.05
        data.overflowguidata.x = (x / data.overflowguidata.scale); data.overflowguidata.y = (y / data.overflowguidata.scale);data.save()}
    if (Settings.manausagegui.isOpen()){
        if (dir == 1) data.manausageguidata.scale += 0.05; 
        else data.manausageguidata.scale -= 0.05
        data.manausageguidata.x = (x / data.manausageguidata.scale); data.manausageguidata.y = (y / data.manausageguidata.scale);data.save()}
    if (Settings.secretsgui.isOpen()){
        if (dir == 1) data.secretsguidata.scale += 0.05; 
        else data.secretsguidata.scale -= 0.05
        data.secretsguidata.x = (x / data.secretsguidata.scale); data.secretsguidata.y = (y / data.secretsguidata.scale);data.save()}
});register("guiMouseClick", (x, y, bn) => {
    if (Settings.healthgui.isOpen() && bn != 2) {
        data.healthguidata.x = (x / data.healthguidata.scale); data.healthguidata.y = (y / data.healthguidata.scale);data.save()} 
    if (Settings.healthgui.isOpen() && (bn == 2)) {
        data.healthguidata.x = Renderer.screen.getWidth() / 2
        data.healthguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.healthguidata.scale = 1;data.save()}
    if (Settings.managui.isOpen() && bn != 2) {
        data.managuidata.x = (x / data.managuidata.scale); data.managuidata.y = (y / data.managuidata.scale);data.save()} 
    if (Settings.managui.isOpen() && (bn == 2)) {
        data.managuidata.x = Renderer.screen.getWidth() / 2
        data.managuidata.y = Renderer.screen.getHeight() / 2 + 10
        data.managuidata.scale = 1;data.save()}
    if (Settings.overflowgui.isOpen() && bn != 2) {
        data.overflowguidata.x = (x / data.overflowguidata.scale); data.overflowguidata.y = (y / data.overflowguidata.scale);data.save()} 
    if (Settings.overflowgui.isOpen() && (bn == 2)) {
        data.overflowguidata.x = Renderer.screen.getWidth() / 2
        data.overflowguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.overflowguidata.scale = 1;data.save()}
    if (Settings.manausagegui.isOpen() && bn != 2) {
        data.manausageguidata.x = (x / data.manausageguidata.scale); data.manausageguidata.y = (y / data.manausageguidata.scale);data.save()} 
    if (Settings.manausagegui.isOpen() && (bn == 2)) {
        data.manausageguidata.x = Renderer.screen.getWidth() / 2
        data.manausageguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.manausageguidata.scale = 1;data.save()}
    if (Settings.secretsgui.isOpen() && bn != 2) {
        data.secretsguidata.x = (x / data.secretsguidata.scale); data.secretsguidata.y = (y / data.secretsguidata.scale);data.save()} 
    if (Settings.secretsgui.isOpen() && (bn == 2)) {
        data.secretsguidata.x = Renderer.screen.getWidth() / 2
        data.secretsguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.secretsguidata.scale = 1;data.save()}
    });register("worldUnload", () => {
        overlayregister1.unregister();overlay1.render = false
        overlayregister2.unregister();overlay2.render = false
        overlayregister3.unregister();overlay3.render = false
        overlayregister4.unregister();overlay4.render = false
        overlayregister5.unregister();overlay5.render = false
    })
//////////////////////

//75/75❤     210❈ Defense     2,461/2,461✎ 600ʬ (9)



let worldloaded
let NOTENOUGHMANAreadtime
let overflowreadtime
let secretsreadtime

register("worldUnload", () => {
    worldloaded = Date.now()
})

register("renderExperience", (event) =>{
    if (Settings.hideexperiencelevels) cancel(event)
})

register("actionBar", (a1,a2,a3,b1,b2,b3,evebt) =>{
    at = a1 + a3
    bt = b1 + b3
    ct = ((at / bt) * 100).toFixed(0)
    if (Settings.changehealthcolors){
        if (ct > 100) colorr = `&6`
        if (Settings.onlyshowcolorforabsorption){
            if (ct <= 100) colorr = `&c`
        } else {
            if (Settings.usepinkforpercent) {
                if (ct <= 100 && ct > 85) colorr = `&d`
            }else {
                if (ct <= 100 && ct > 85) colorr = `&c`
            }
            if (ct <= 85 && ct > 50) colorr = `&c`
            if (ct <= 50 && ct > 20) colorr = `&4`
            if ( ct <= 20) colorr = `&0`
        }
    } else colorr = `&c`
    if (ct <= Settings.healthpercenttoshow || Settings.healthpercenttoshow == 101){
        overlay1.render = true

        if (Settings.usehealthicon) icon = `❤`; else icon = ` `
        if (Settings.onlyshowhealthicon) return overlay1.title = `${colorr}❤`
        if (Settings.usehealthpercent){
            overlay1.title = `${colorr}${ct}%${icon}`
        } else {
            overlay1.title = `${colorr}${a1}${a2}${a3}/${b1}${b2}${b3}${icon}`
        }
    } else {
        overlay1.render = false
        overlayregister1.unregister()
    }
}).setCriteria(/(\d+)(,)?(\d+)?\/(\d+)(,)?(\d+)?❤.*/)

register("actionBar", (a1,a2,a3,b1,b2,b3,evebt) =>{
    at = a1 + a3
    bt = b1 + b3
    ct = ((at / bt) * 100).toFixed(0)
    if (Settings.changemanacolors){
        if (ct > 60) colorr = `&b`
        if (ct <= 60 && ct > 30) colorr = `&9`
        if ( ct <= 30) colorr = `&1`
    } else colorr = `&b`
    if (ct <= Settings.manapercenttoshow || Settings.manapercenttoshow == 101){
        overlay2.render = true
        if (Settings.usemanaicon && Settings.uselessuglymanaicon) icon = `✦`
        else if (Settings.usemanaicon) icon = `✎`; else icon = ` `
        if (Settings.usemanaicon && Settings.onlyshowmanaicon) return overlay2.title = `${colorr}${icon}`
        if (Settings.usemanapercent) overlay2.title = `${colorr}${ct}%${icon}`
        else{overlay2.title = `${colorr}${a1}${a2}${a3}/${b1}${b2}${b3}${icon}`}
    } else {
        overlay2.render = false
        overlayregister2.unregister()
    }
}).setCriteria(/.*?(\d+)(,)?(\d+)?\/(\d+)(,)?(\d+)?✎.*/)

register("actionBar", (a1,evebt) =>{
    NOTENOUGHMANAreadtime = Date.now()
    overlay2.title = `&cNOT ENOUGH MANA`
    overlay2.render = true
}).setCriteria(/.*?(NOT ENOUGH MANA).*?/)

register("actionBar", (a1,a2,evebt) =>{
    secretsreadtime = Date.now()
    if (Settings.secretstitle)title = `&7Secrets\n`
    else title = ` `
    overlay5.title = `${title}    &f${a1}&7/&f${a2}`
    overlay5.render = true
    setTimeout(() => {
        if ((Date.now() - secretsreadtime) > 1000){
            overlay5.render = false
            overlayregister5.unregister()
        }
    }, 2000);
}).setCriteria(/.*?(\d+)\/(\d+) Secrets.*/)

register("actionBar", (a1,evebt) =>{
    renderstarttime = Date.now()
    overlay3.title = `&3${a1}ʬ`
    overlay3.render = true
    setTimeout(() => {
        if ((Date.now() - renderstarttime) > 750){
            overlay3.render = false
            overlayregister3.unregister()
        }
    }, 800);
}).setCriteria(/.*?(\d+)ʬ.*?/)

register("actionBar", (manaused,name,evebt) =>{
    renderstarttime = Date.now()
    titlee = `&b-${manaused} Mana (&6${name}&b)`
    overlay4.render = true
    overlay4.title = titlee
    setTimeout(() => {
        if ((Date.now() - renderstarttime) > 750){
            overlay4.render = false
            overlayregister4.unregister()
        }
    }, 800);
}).setCriteria(/.*?-(\d+) Mana \((.+)\).*?/)

register("actionBar", (evebt) =>{
    if (Settings.hideactionbar)cancel(evebt)
}).setCriteria(/.*/)
//

// register("actionBar", (a,evebt) =>{
//     ChatLib.chat(a)
// }).setCriteria(/(.*)/)

// field_71068_ca
// const walkSpeed = (Player.getPlayer().field_71075_bZ.func_75094_b()).toFixed(4)
// let left = new KeyBind(Client.getMinecraft().field_71474_y.field_74370_x)
// Player.getPlayer().field_70125_A = 16;
// 






