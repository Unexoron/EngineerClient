import Settings from "../../config"

// register("command", () => {
//     ChatLib.command(`warp gold`)
//     setTimeout(() => {
//         ChatLib.command(`warp drag`)
//         setTimeout(() => {
//             checkifstage4()
//         }, 1000)
//     }, 4000)
// }).setName("startswap");


// function checkifstage4() {
//     TabList.getNames().forEach((line) => {
//         cleanedLine = ChatLib.removeFormatting(line).trim();
//         if (cleanedLine.includes('Protector:')) {
//                 let protectorStage = cleanedLine.split(' ')[10]
//                 ChatLib.chat(protectorStage)
//         } 
//     });
// }

// register("command", () => {
//     ChatLib.chat(TabList.getNames())
//     ChatLib.chat(TabList.getUnformattedNames())
//     ChatLib.chat(TabList.getNamesByObjectives())
// }).setName("tablisttest");

// function updatetabinfo() {
//     TabList.getNames().forEach((line) => {
//         cleanedLine = ChatLib.removeFormatting(line).trim();
//         if (cleanedLine.includes('Secrets Found:')) {
//             if (cleanedLine.includes('%')) {
//                 let secretString = cleanedLine.split(' ')[2]
//                 secretString = secretString.substring(0, secretString.length - 1)
//                 secretPercentFound = parseFloat(secretString); // Secrets percentage
//             } else {
//                 collectedSecrets = parseInt(cleanedLine.split(' ')[2]) // Secrets number
//             }
//         } else if (cleanedLine.includes('Crypts:')) {
//             let cryptString = cleanedLine.split(' ')[1]
//             crypts = parseInt(cryptString)
//         } else if (cleanedLine.includes('Team Deaths:')) {
//             let deathString = cleanedLine.split(' ')[2];
//             deathString = deathString.substring(1, deathString.length - 1);
//             deaths = parseInt(deathString);
//         } else if (cleanedLine.includes('Completed Rooms:')) {
//             completedRoomString = cleanedLine.split(' ')[2];
//             completedRooms = parseInt(completedRoomString);
//         } else if (cleanedLine.includes('Puzzles:')) {
//             puzzleCountString = cleanedLine.split(' ')[1];
//             puzzleCountString = puzzleCountString.substring(1, puzzleCountString.length - 1);
//             puzzleCount = parseInt(puzzleCountString);
//             unfinishedPuzzles = puzzleCount;
//         } else if (puzzleCount > 0) {
//             if (cleanedLine.includes('[✔]')) {
//                 unfinishedPuzzles--;
//             }
//             puzzleCount--;
//         }
//     });
// }