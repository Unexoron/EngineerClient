import Settings from "../../config";











const uselessMsgs = [
    //////////////////////////////////////////
    /Creeper Veil Activated!/,
    /Creeper Veil De-activated!/,
    //////////////////////////////////////////
    /./,
    /./,
    /./,
    /A Wither Key was picked up!/,
    /\$SKYTILS-DUNGEON-SCORE-MIMIC\$/,
    /.*Mimic Killed!/,
    /.*Skytils-SC.*/,
    /       /,
    /Warping you to your SkyBlock island.../,
    /You earned .+ Event EXP from playing SkyBlock!/,
    /Warping.../,
    /Watchdog has banned .+ players in the last 7 days./,
    /RARE REWARD!.+/,
    /Error initializing players\: undefined/,
    /You are playing on profile\: .+/,
    /Profile ID\:.+/,
    /.+Mimic Killed!/,
    /Goldor's TNT Trap hit you for 1,788.9 true damage./,
    /A Blood Key was picked up/,
    /This Terminal doesn't seem to be responsive at the moment./,
    /Whow! Slow down there!/,
    /⚠ Storm is enraged! ⚠/,
    /Giga Lightning.+/,
    /Necron's Nuclear Frenzy hit you for .+ damage./,
    /Woah slow down, you're doing that too fast!/,
    /Command Failed: This command is on cooldown! Try again in about a second!/,
    /Someone has already activated this lever!/,
    /Goldor's Greatsword hit you for .+ damage./,
    /A mystical force in this room prevents you from using that ability!/,
    /The Frozen Adventurer used Ice Spray on you!/,
    /It isn't your turn!/,
    /That chest is locked!/,
    /Autopet equipped your.+/,
    /Don't move diagonally! Bad!/,
    /Oops! You stepped on the wrong block!/,
    /Used Ragnarok!/,
    /Your Auto Recombobulator recombobulated/,
    /You cannot use abilities in this room!/,
    /A shiver runs down your spine.../,
    /The BLOOD DOOR has been opened!/,
    /.*Granted you.+/,
    /Blacklisted modifications are a bannable offense!/,
    /\[WATCHDOG ANNOUNCEMENT\]/,
    /Staff have banned an additional .+/,
    /Your Ultimate is currently on cooldown for .+ more seconds./,
    /ESSENCE! .+ found .+ Essence!/,
    /This lever has already been used./,
    /You hear the sound of something opening.../,
    /This chest has already been searched!/,
    /A Blessing of .+ was picked up!/,
    /.*Also granted you.+/,
    /The Lost Adventurer used Dragon's Breath on you!/,
    /A Blessing of .+/,
    /You sold .+ x.* for .+/,
    /You don't have enough space in your inventory to pick up this item!.*/,
    /Inventory full\? Don't forget to check out your Storage inside the SkyBlock Menu!/,
    /Your Berserk ULTIMATE Ragnarok is now available!/,
    /Granted you.+/,
    /This item's ability is temporarily disabled!/,
    /Throwing Axe is now available!/,
    /Used Throwing Axe!/,
    `OpenGL Error: 1281 (Invalid value)`,
    `You have 60 seconds to warp out! CLICK to warp now!`,
    `The gate has been destroyed!`,
    `The Core entrance is opening!`,
    /You are not allowed to use Potion Effects.+/,
    /\[STATUE\].+/,
    /\[NPC\] (Hugo)/,
    /PUZZLE SOLVED!.+/,
    /DUNGEON BUFF! .+/,
    /A Crypt Wither Skull exploded, hitting you for .+ damage./,
    /.+ opened a WITHER door!/,
    /\[[Tank|Healer|Mage|Archer|Berserk]+\] .+/,
    /\[SKULL\] .+/,
    /You summoned your.+/,
    /\[BOMB\] Creeper:.+/,
    /\[Sacks\] .+ item.+/,
    /The .+ Trap hit you for .+ damage!/,
    /Healer Milestone.+/,
    /Archer Milestone.+/,
    /Mage Milestone.+/,
    /Tank Milestone.+/,
    /Berserk Milestone.+/,
    /.+has obtained.+/,
    /RARE DROP!.+/,
    /There are blocks in the way!/,
    /Error initializing players: undefined Hidden/,
    /Your .+ stats are doubled because you are the only player using this class!/,
    /Moved .+ Ender Pearl from your Sacks to your inventory./,
    /Skytils.+Something isn't right! .*/,
    /You have .+ unclaimed .+/,
    /Click here to view them!/,
    /.+ joined the lobby! .*/,
    /Welcome to Hypixel SkyBlock!/,
    /Latest update: SkyBlock .+/,
    /BONUS! Temporarily earn 5% more skill experience!/,
    /.+ is now ready!/,
    /Sending to server .+/,
    /Queuing... .+/,
    /.+ Milestone .+:.+ /,
    /Your CLASS stats are doubled because you are the only player using this class!/,
    /RIGHT CLICK on .+ to open it. .+/,
    /\[BOSS\] .+/,
    /.+ Mort: .+/,



    /Your .+ hit .+ for [\d,.]+ damage./,
    /You do not have enough mana to do this!/,
    /.+Kill Combo+/,
    /Thunderstorm is ready to use! Press DROP to activate it!/,
    /.+ healed you for .+ health!/,
    /You earned .+ GEXP .*/,
    /.+ unlocked .+ Essence!/,
    /.+ unlocked .+ Essence x\d+!/,
    /This menu is disabled here!/,
    /This item is on cooldown.+/,
    /This ability is on cooldown.+/,
    /You do not have the key for this door!/,
    /The Stormy .+ struck you for .+ damage!/,
    /Please wait a few seconds between refreshing!/,
    /You cannot move the silverfish in that direction!/,
    /You cannot hit the silverfish while it's moving!/,
    /Your Kill Combo has expired! You reached a .+ Kill Combo!/,
    /Your active Potion Effects have been paused and stored. They will be restored when you leave Dungeons! You are not allowed to use existing Potion Effects while in Dungeons./,
    /.+ has obtained Blood Key!/,
    /The Flamethrower hit you for .+ damage!/,
    /.+ found a Wither Essence! Everyone gains an extra essence!/,
    /Ragnarok is ready to use! Press DROP to activate it!/,
    /This creature is immune to this kind of magic!/,
    /FISHING FESTIVAL The festival is now underway! Break out your fishing rods and watch out for sharks!/
]



uselessMsgs.forEach(msg => {
    register("chat", event => {
        if (!Settings.chatcleaner) return
        cancel(event)
    }).setCriteria(msg)
})



register("chat", (aaaaaaaa,dbfdb,event) => {
    if (!Settings.cleanfriendjoin) return
    cancel(event)
    if (dbfdb == "joined") ChatLib.chat(`&2 >>&a ${aaaaaaaa}`)
    if (dbfdb == "left") ChatLib.chat(`&4 <<&c ${aaaaaaaa}`)
    
}).setCriteria(/Friend > (.+) (.+)\./)


register("chat", (aaaaaaaa,dbfdb,event) => {
    if (!Settings.chatcleaner) return
    cancel(event)
    if (dbfdb == "joined") ChatLib.chat(`&2 >> &a${aaaaaaaa}`)
    if (dbfdb == "left") ChatLib.chat(`&4 <<&c ${aaaaaaaa}`)
    
}).setCriteria(/Guild > (.+) (.+)\./)


register("chat", (nbgweriuhbiuwerg,aaaaaaaa,bbbbbbbbbb,event) => {
    if (!Settings.cleanpartychat) return
    cancel(event)
    ChatLib.chat(`  &9> &b${aaaaaaaa}&f: ${bbbbbbbbbb}`)
}).setCriteria(/Party > (\[.+\])? ?(.+): (.*)/)


register("chat", (aaaaaaaa,bbbbbbbbbb,event) => {
    if (!Settings.chatcleaner) return
    cancel(event)
     if (bbbbbbbbbb == "Phoenix" || bbbbbbbbbb == "Phoenix ✦"){ChatLib.chat(`&5Phoenix`)}
     if (bbbbbbbbbb == "Black Cat" || bbbbbbbbbb == "Black Cat ✦"){ChatLib.chat(`&6Black Cat`)}
    // ChatLib.chat(`&9 Autopet &f${bbbbbbbbbb}`)
}).setCriteria(/Autopet equipped your \[Lvl (\d+)\] (.+)! VIEW RULE/)




register("command", () => {
    ChatLib.chat(`&00 &11 &22 &33 &44 &55 &66 &77 &88 &99 &aa &bb &cc &dd &ee &ff`)
}).setName("colorr")