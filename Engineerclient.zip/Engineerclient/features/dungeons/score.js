


///// RENDERING /////
// each setting will only effects 2 variables
// settingsgui and settingsguidata
import Settings from "../../config"
import { data } from "../../utils/data"
let testtitle1 = [`270`];let testtitle2 = [`300`]
const overlay1 = {render: null, title: "gb8yuwe2983th2398", truetitleDONTUSE: `scorecalcgui`};
const overlayregister1 = register("renderOverlay", () => {
    Renderer.scale(data.scorecalcguidata.scale);Renderer.drawStringWithShadow((overlay1.truetitleDONTUSE),data.scorecalcguidata.x, data.scorecalcguidata.y)}).unregister();
let gui1on
function registerall(){overlay1.render = true;overlayregister1.register()}; 
function unregisterall(){overlay1.render = false;overlayregister1.unregister()}
register("step", () => {
    if (Settings.scorecalcgui.isOpen()) registerall();if (overlay1.render) { overlayregister1.register();  
        if (Settings.scorecalcgui.isOpen()) {overlay1.truetitleDONTUSE = testtitle1;gui1on = true}
        else if (!Settings.scorecalcgui.isOpen() && gui1on) {unregisterall();overlay1.truetitleDONTUSE = " "; gui1on = false}
        else overlay1.truetitleDONTUSE = overlay1.title}
}).setFps(10);register("dragged", (dx, dy, x, y, bn) => {
    if (Settings.scorecalcgui.isOpen() && bn != 2){
        data.scorecalcguidata.x = (x / data.scorecalcguidata.scale); data.scorecalcguidata.y = (y / data.scorecalcguidata.scale);data.save()}
});register("scrolled", (x, y, dir) => {
    if (Settings.scorecalcgui.isOpen()){
        if (dir == 1) data.scorecalcguidata.scale += 0.05;else data.scorecalcguidata.scale -= 0.05
        data.scorecalcguidata.x = (x / data.scorecalcguidata.scale); data.scorecalcguidata.y = (y / data.scorecalcguidata.scale);data.save()}
    if (Settings.sectiontimesgui.isOpen()){
        if (dir == 1) data.sectiontimesguidata.scale += 0.05; else data.sectiontimesguidata.scale -= 0.05
        data.sectiontimesguidata.x = (x / data.sectiontimesguidata.scale); data.sectiontimesguidata.y = (y / data.sectiontimesguidata.scale);data.save()}
});register("guiMouseClick", (x, y, bn) => {
    if (Settings.scorecalcgui.isOpen() && bn != 2) {
        data.scorecalcguidata.x = (x / data.scorecalcguidata.scale); data.scorecalcguidata.y = (y / data.scorecalcguidata.scale);data.save()} 
    if (Settings.scorecalcgui.isOpen() && (bn == 2)) {
        data.scorecalcguidata.x = Renderer.screen.getWidth() / 2;data.scorecalcguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.scorecalcguidata.scale = 1;data.save()}
    });register("worldUnload", () => {overlayregister1.unregister();overlay1.render = false})
    register("command", () => {overlay1.render = true
        setTimeout(() => {overlay1.render = false;overlayregister1.unregister()}, 2000)
    }).setName("testscorecalcpos");
///// /////





















// function updatetabinfo() {
//     TabList.getNames().forEach((line) => {
//         cleanedLine = ChatLib.removeFormatting(line).trim();
//         if (cleanedLine.includes('Secrets Found:')) {
//             if (cleanedLine.includes('%')) {
//                 let secretString = cleanedLine.split(' ')[2]
//                 secretString = secretString.substring(0, secretString.length - 1)
//                 secretPercentFound = parseFloat(secretString); // Secrets percentage
//             } else {
//                 collectedSecrets = parseInt(cleanedLine.split(' ')[2]) // Secrets number
//             }
//         } else if (cleanedLine.includes('Crypts:')) {
//             let cryptString = cleanedLine.split(' ')[1]
//             crypts = parseInt(cryptString)
//         } else if (cleanedLine.includes('Team Deaths:')) {
//             let deathString = cleanedLine.split(' ')[2];
//             deathString = deathString.substring(1, deathString.length - 1);
//             deaths = parseInt(deathString);
//         } else if (cleanedLine.includes('Completed Rooms:')) {
//             completedRoomString = cleanedLine.split(' ')[2];
//             completedRooms = parseInt(completedRoomString);
//         } else if (cleanedLine.includes('Puzzles:')) {
//             puzzleCountString = cleanedLine.split(' ')[1];
//             puzzleCountString = puzzleCountString.substring(1, puzzleCountString.length - 1);
//             puzzleCount = parseInt(puzzleCountString);
//             unfinishedPuzzles = puzzleCount;
//         } else if (puzzleCount > 0) {
//             if (cleanedLine.includes('[✔]')) {
//                 unfinishedPuzzles--;
//             }
//             puzzleCount--;
//         }
//     });
// }

// function calculateScore() {
//     if (crypts > 5) {
//         crypts = 5
//     } if (deaths === 0) {
//         deaths = 0.5
//     } if (bloodGreenChecked === true) {
//         bonusScore = (crypts + mimicScore)
//         skillScore = 20 + (80 * (completedRooms/totalRooms)) - (10 * unfinishedPuzzles) - ((2 * deaths) - 1)
//         exploreScore = (60 * (completedRooms/totalRooms)) + (40 * (secretPercentFound/secretPercentNeeded))
//         scoredisplay = Math.floor(bonusScore + skillScore + exploreScore + 100).toFixed(0)
//     } if (bloodGreenChecked === false) {
//         bonusScore = (crypts + mimicScore) + 4
//         skillScore = 20 + (80 * (completedRooms/totalRooms)) - (10 * unfinishedPuzzles) - ((2 * deaths) - 1)
//         exploreScore = (60 * (completedRooms/totalRooms)) + (40 * (secretPercentFound/secretPercentNeeded))
//         scoredisplay = Math.floor(bonusScore + skillScore + exploreScore + 100).toFixed(0)
//     }
// }



// register('tick', () => {
//     if(startBloodCheckScan == true) {
//         kingsdev()
//     }
//     updatetabinfo()
//     calculateScore()
//     bloodTicksSinceOpened++
// });

// let scoredisplay = 0
// let exploreScore = 0
// let secretPercentNeeded = 100
// let totalRooms = 35
// let deathPenalty = 0
// let cryptsKilled = 0
// let mimicScore = 0
// let completedRooms
// let failedPuzzles
// let secretPercentFound
// let puzzleCount
// let deaths
// let crypts
// let unfinishedPuzzles
// let watcherKillMobDialogueLines = 0
// let watcherTotalDialogueLines = 0
// let bloodGreenChecked = false
// let bloodTicksSinceOpened = 0
// let startBloodCheckScan = false

// bonusScore = (cryptsKilled + mimicScore)
// skillScore = 20 + (80 * (completedRooms/totalRooms)) - (10 * failedPuzzles) - deathPenalty
// exploreScore = (60 * (completedRooms/totalRooms)) + (40 * (secretPercentFound/secretPercentNeeded))

// var objective = "Completed Rooms";


// register("command", () => {
//     console.log(TabList.getNames())
// }).setName("testtab");

// register("command", () => {
//     ChatLib.chat(bonusScore)
//     ChatLib.chat(skillScore)
//     ChatLib.chat(exploreScore)
// }).setName("detailedscore");

// register("command", () => {
//     calculateScore()
//     ChatLib.chat(scoredisplay)
// }).setName("updatetabinfo");

// register("command", () => {
//     console.log(TabList.getUnformattedNames())
// }).setName("testtab2");

// register("command", () => {
//     console.log(TabList.getNamesByObjectives(objective))
// }).setName("testtab3");

// register("chat", () => {
//     mimicScore = 2
// }).setCriteria("Mimic Killed!").setContains()

// register("chat", () => {
//     watcherKillMobDialogueLines++
// }).setCriteria("[BOSS] The Watcher: Not bad.").setContains()

// register("chat", () => {
//     watcherKillMobDialogueLines++
// }).setCriteria("[BOSS] The Watcher: That one was weak anyway.").setContains()

// register("chat", () => {
//     watcherKillMobDialogueLines++
// }).setCriteria("[BOSS] The Watcher: I'm impressed.").setContains()

// register("chat", () => {
//     watcherKillMobDialogueLines++
// }).setCriteria("[BOSS] The Watcher: Very nice.").setContains()

// register("chat", () => {
//     watcherKillMobDialogueLines++
// }).setCriteria("[BOSS] The Watcher: Aw, I liked that one.").setContains()

// register("chat", () => {
//     startBloodCheckScan = true
// }).setCriteria("[BOSS] The Watcher: You have proven yourself. You may pass.").setContains()

// register("command", () => {
//     ChatLib.chat(watcherKillMobDialogueLines)
//     ChatLib.chat(watcherTotalDialogueLines)
// }).setName("testwatcherdialogue");

// register("chat", () => {
//     mimicScore = 2
// }).setCriteria("$SKYTILS-DUNGEON-SCORE-MIMIC$").setContains()

// register("chat", () => {
//     bloodTicksSinceOpened = 0
// }).setCriteria("[BOSS] The Watcher: Things feel a little more roomy now, eh?").setContains()

// const unloadTrigger = register("worldUnload", () => {
//     mimicScore = 0
//     watcherKillMobDialogueLines = 0
//     watcherTotalDialogueLines = 0
//     startBloodCheckScan = false
// })

// function kingsdev() {
//     try {
//         let item = Player.getInventory().getStackInSlot(8);
//         let mapData = item.getItem()["func_77873_a"](item.getItemStack(), World.getWorld());
//         let mapColors = mapData["field_76198_e"];
//         let g = [];
//         for (let i = 0; i < mapColors.length; i++) {
//             if (mapColors[i] === 18) {
//                 g.push(i);
//             }
//         }
//         let x = g[0] % 128;
//         let y = Math.floor(g[0] / 128);
//         let colour = mapColors[(x + 4) + ((y + 9) * 128)];
//         if (!bloodGreenChecked && colour === 30) {
//             bloodGreenChecked = true;
//             ChatLib.chat("§ZBlood done!");
//             startBloodCheckScan = false
//         }
//     } catch (e) {}
// }

// register("chat", () => {
//     bloodGreenChecked = false;
// }).setCriteria(/^.*is now ready!$/);