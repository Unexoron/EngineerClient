import RenderLibV2 from "../../../RenderLibV2"
import Settings from "../../config"
import { prefix } from "../../utils/utils"

let doingi4 = false

register("chat", ()=> {
    doingi4 = true
    setTimeout(() => {
        doingi4 = false
    }, 17000);
}).setCriteria("[BOSS] Storm: I should have known that I stood no chance.");



register("soundPlay", (a,b,c,d,e,event) => {
    if (a.x <= 65.2 && a.x >= 63.4 && a.y <= 128 && a.y >= 107 && a.z <= 37.3 && a.z >= 34.3) {
        cancel(event)
        World.playSound("note.pling", 0.68, 0.8)
    }
}).setCriteria("random.bow")


register("soundPlay", (a,b,c,d,e,event) => {
    cancel(event)
    setTimeout(() => {
        World.playSound("note.pling", 0.68, 0.8)
    }, 50);
    /*
    if((Player.getX() <= 65.2) && (Player.getX() >= 63.4) && 
    (Player.getY() <= 128) && (Player.getY() >= 107)&& 
    (Player.getY() <= 37.3) && (Player.getY() >= 34.3)){

    } */
}).setCriteria("mob.bat.death")



// register("step", () => {
//     if (Keyboard.isKeyDown(Keyboard.KEY_W) && Keyboard.isKeyDown(Keyboard.KEY_D) && (Keyboard.isKeyDown(Keyboard.KEY_A) == false)) {
//         overlayTriggerWDline.register()
//     } else {
//         overlayTriggerWDline.unregister()
//     }
// }).setFps(10);
