const S32PacketConfirmTransaction = Java.type("net.minecraft.network.play.server.S32PacketConfirmTransaction");
///// RENDERING /////
// each setting will only effects 2 variables
// settingsgui and settingsguidata
import Settings from "../../config"
import { data } from "../../utils/data"
let testtitle1 = [`&6Terminals: &c1&7/&c4
&6Levers: &a2&7/&a2
&6Device: &cx
&6Gate: &a✔`];let testtitle2 = [`test`]
const overlay1 = {render: null, title: "&c0&7/&a7", truetitleDONTUSE: `p3gui`};
const overlay2 = {render: null, title: "e5i465i56i65herh", truetitleDONTUSE: `sectiontimesgui`};
const overlayregister1 = register("renderOverlay", () => {
    Renderer.scale(data.p3guidata.scale);Renderer.drawStringWithShadow((overlay1.truetitleDONTUSE),data.p3guidata.x, data.p3guidata.y)}).unregister();
const overlayregister2 = register("renderOverlay", () => {
    Renderer.scale(data.sectiontimesguidata.scale);Renderer.drawStringWithShadow((overlay2.truetitleDONTUSE),data.sectiontimesguidata.x, data.sectiontimesguidata.y)}).unregister();
let gui1on; let gui2on
function registerall(){
    overlay1.render = true;overlayregister1.register();overlay2.render = true;overlayregister2.register()}; function unregisterall(){
    overlay1.render = false;overlayregister1.unregister();overlay2.render = false;overlayregister2.unregister()}
register("step", () => {
    if (Settings.p3gui.isOpen()) registerall();if (overlay1.render) { overlayregister1.register();  
        if (Settings.p3gui.isOpen()) {overlay1.truetitleDONTUSE = testtitle1;gui1on = true}
        else if (!Settings.p3gui.isOpen() && gui1on) {unregisterall();overlay1.truetitleDONTUSE = " "; gui1on = false}
        else overlay1.truetitleDONTUSE = overlay1.title}
    if (Settings.sectiontimesgui.isOpen()) registerall();if (overlay2.render) { overlayregister2.register(); 
        if (Settings.sectiontimesgui.isOpen()) {overlay2.truetitleDONTUSE = testtitle2;gui2on = true}
        else if (!Settings.sectiontimesgui.isOpen() && gui2on) {unregisterall();overlay2.truetitleDONTUSE = " "; gui2on = false}
        else overlay2.truetitleDONTUSE = overlay2.title}
}).setFps(10);register("dragged", (dx, dy, x, y, bn) => {
    if (Settings.p3gui.isOpen() && bn != 2){
        data.p3guidata.x = (x / data.p3guidata.scale); data.p3guidata.y = (y / data.p3guidata.scale);data.save()}
    if (Settings.sectiontimesgui.isOpen() && bn != 2){
        data.sectiontimesguidata.x = (x / data.sectiontimesguidata.scale); data.sectiontimesguidata.y = (y / data.sectiontimesguidata.scale);data.save()}
});register("scrolled", (x, y, dir) => {
    if (Settings.p3gui.isOpen()){
        if (dir == 1) data.p3guidata.scale += 0.05;else data.p3guidata.scale -= 0.05
        data.p3guidata.x = (x / data.p3guidata.scale); data.p3guidata.y = (y / data.p3guidata.scale);data.save()}
    if (Settings.sectiontimesgui.isOpen()){
        if (dir == 1) data.sectiontimesguidata.scale += 0.05; else data.sectiontimesguidata.scale -= 0.05
        data.sectiontimesguidata.x = (x / data.sectiontimesguidata.scale); data.sectiontimesguidata.y = (y / data.sectiontimesguidata.scale);data.save()}
});register("guiMouseClick", (x, y, bn) => {
    if (Settings.p3gui.isOpen() && bn != 2) {
        data.p3guidata.x = (x / data.p3guidata.scale); data.p3guidata.y = (y / data.p3guidata.scale);data.save()} 
    if (Settings.p3gui.isOpen() && (bn == 2)) {
        data.p3guidata.x = Renderer.screen.getWidth() / 2;data.p3guidata.y = Renderer.screen.getHeight() / 2 + 10
        data.p3guidata.scale = 1;data.save()}
    if (Settings.sectiontimesgui.isOpen() && bn != 2) {
        data.sectiontimesguidata.x = (x / data.sectiontimesguidata.scale); data.sectiontimesguidata.y = (y / data.sectiontimesguidata.scale);data.save()} 
    if (Settings.sectiontimesgui.isOpen() && (bn == 2)) {
        data.sectiontimesguidata.x = Renderer.screen.getWidth() / 2;data.sectiontimesguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.sectiontimesguidata.scale = 1;data.save()}
    });register("worldUnload", () => {
        overlayregister1.unregister();overlay1.render = false
        overlayregister2.unregister();overlay2.render = false
    worldloadd()})
    register("command", () => {overlay1.render = true;overlay2.render = true
        setTimeout(() => {overlay1.render = false;overlayregister1.unregister()
        overlay2.render = false;overlayregister2.unregister()}, 2000)
    }).setName("testp3pos");
///// /////



function worldloadd(){
    insection = 0
    lastCompleted = [0, 7]
    gateBlown = false
    phaseStarted = null
    sectionStarted = null
    termreport = []
    terminalscompleted = 0
    leverscompleted = 0
    firstdevcheck = false
    seconddevcheck = false
    thirddevcheck = false
    devicescompleted = 0
    device1completed = false
    device2completed = false
    device3completed = false
    device4completed = false
    devbompleted = false
}
let insection = 0
let lastCompleted = [0, 7]
let gateBlown = false
let phaseStarted = null
let sectionStarted = null
let termreport = []
let terminalscompleted = 0
let leverscompleted = 0
let devicescompleted = 0
let device1completed = false
let device2completed = false
let device3completed = false
let device4completed = false
let firstdevcheck = false
let seconddevcheck = false
let thirddevcheck = false
let devbompleted = false

const newSection = () => {
    insection++
    let secs = ((Date.now() - sectionStarted)/1000).toFixed(2)
    sectionStarted = Date.now()
    lastCompleted = [0, 7]
    terminalscompleted = 0
    leverscompleted = 0
    gateBlown = false
    devbompleted = false
    updatep3gui()
    if (!Settings.sectiontimes) return
    World.playSound("random.eat", 5, 1)
    if (secs > 200) {overlay2.title = `&3>200s`} else overlay2.title = `&3${secs}s`
    overlay2.render = true
    setTimeout(() => {  
        overlay2.render = false
        overlayregister2.unregister()
    }, 5000);
}
// void first dev check
// 2nd dev check if 2 fi2 and i4

register("chat", () => {
    insection = 1
    phaseStarted = Date.now()
    sectionStarted = Date.now()
    overlay1.render = true
    updatep3gui()
    firstdevcheck = true
    setTimeout(() => {
        firstdevcheck = false
        seconddevcheck = true
    }, 3000);
    setTimeout(() => {
        seconddevcheck = false
    }, 9000);
}).setCriteria("[BOSS] Goldor: Who dares trespass into my domain?"),

register("chat", (name, action, object, completed, total, event) => {
    completed = parseInt(completed)
    total = parseInt(total)
    let timeSection = ((Date.now() - sectionStarted) / 1000).toFixed(2)
    let timePhase = ((Date.now() - phaseStarted) / 1000).toFixed(2)
    let message = ChatLib.getChatMessage(event, true)
    let formattedName = message.substring(0, name.length + 6)
    if (object == "terminal") terminalscompleted++
    if (object == "device") devicescompleted++
    if (object == "lever") leverscompleted++
    updatep3gui()
    termreport.push(`${formattedName} &a${action} ${object}! (&c${completed}&a/${total}) &8(&7${timeSection}s &8| &7${timePhase}s&8)`)
    if (completed < lastCompleted[0] || (completed == total && gateBlown)) return newSection()
    lastCompleted = [completed, total]
}).setCriteria(/(\w+) (activated|completed) a (terminal|device|lever)! \((\d)\/(\d)\)/)

register("chat", (event) => {
    let timeSection = ((Date.now() - sectionStarted) / 1000).toFixed(2)
    let timePhase = ((Date.now() - phaseStarted) / 1000).toFixed(2)
    termreport.push(`&aThe gate has been destroyed! &8(&7${timeSection}s &8| &7${timePhase}s&8)`)
    if (lastCompleted[0] == lastCompleted[1]) newSection()
    else gateBlown = true
    updatep3gui()
}).setCriteria("The gate has been destroyed!")

register("chat", (event) => {
    phaseStarted = null
    sectionStarted = null
    setTimeout(() => {
        overlay1.render = false;overlayregister1.unregister()
    }, 2000);
}).setCriteria("The Core entrance is opening!")

function updatep3gui(){
    if (!Settings.p3infosimple && !Settings.p3info) overlay1.title = ` `
    if (Settings.p3info) {
        if (insection == 2) totalterms = 5; else totalterms = 4
    if (terminalscompleted == totalterms) termscolor = `&a`; else termscolor = `&c`


    if (leverscompleted == 2) leverscolor = `&a`; else leverscolor = `&c`


    if (insection == 1){
        if (firstdevcheck && devicescompleted > 0) devicescompleted = 0
        if (seconddevcheck && devicescompleted == 1) {device4completed = true; devicescompleted = 0}
        else if (seconddevcheck && devicescompleted == 2) {device2completed = true; devicescompleted = 0}
        else if (devicescompleted > 0) {device1completed = true;devbompleted = true; devicescompleted = 0}
    } else if (insection == 2){
        if (device2completed) devbompleted = true
        else if (devicescompleted > 0) {device2completed = true;devbompleted = true; devicescompleted = 0}
    } else if (insection == 3){
        if (devicescompleted > 0) {device3completed = true;devbompleted = true; devicescompleted = 0}
    } else if (insection == 4){
        if (device4completed) devbompleted = true
        else if (devicescompleted > 0) {device4completed = true;devbompleted = true; devicescompleted = 0}
    }
    if (devbompleted) devbleeded = `&a✔`; else devbleeded = `&cx`
    if (gateBlown) gatebleeded = `&a✔`; else gatebleeded = `&cx`
    if (insection !== 4) finalgatedisplay = `&6Gate ${gatebleeded}`; else finalgatedisplay = ` `
    if (!Settings.p3infosimple) overlay1.title = 
`&6Terminals ${termscolor}${terminalscompleted}&7/${termscolor}${totalterms}
&6Levers ${leverscolor}${leverscompleted}&7/${leverscolor}2
&6Device ${devbleeded}
${finalgatedisplay}`
    }
}



register("command", () => {
    ChatLib.chat("ihwbegriewgubr")
    newSection()
}).setName("neww");

register("command", () => {
    ChatLib.chat("ihwbegriewwwwgubr")
    overlay1.render = true; overlay1.title = `&9AHHHHHHHHHHHHHHHHs`; overlay1.totaltime = 2500; overlay1.started = Date.now();
}).setName("/ttest");

register("command", () => {
    termreport.forEach(item => ChatLib.chat(item));
}).setName("tr");




register("chat", (message) => {
    if (((message).includes(`(1/7)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&c1&7/&c7`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(2/7)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&c2&7/&c7`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(3/7)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&c3&7/&c7`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(4/7)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&e4&7/&e7`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(5/7)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&e5&7/&e7`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(6/7)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&e6&7/&e7`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(7/7)`)) && Settings.p3infosimple) {
        if (insection == 1 || insection == 2) {
            overlay1.title = `&c0&7/&c8`
        } if (insection == 3) {
            overlay1.title = `&c0&7/&a7`
        } if (insection == 4) {
            overlay1.title = ` `
        }
    }
}).setCriteria("${message}")



register("chat", (message) => {
    if (((message).includes(`(1/8)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&c1&7/&c8`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(2/8)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&c2&7/&c8`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(3/8)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&c3&7/&c8`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(4/8)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&e4&7/&e8`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(5/8)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&e5&7/&e8`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(6/8)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&a6&7/&a8`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(7/8)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&a7&7/&a8`
    }
}).setCriteria("${message}")

register("chat", (message) => {
    if (((message).includes(`(8/8)`)) && insection !== 0 && Settings.p3infosimple) {
        overlay1.title = `&c0&7/&c7`
    }
}).setCriteria("${message}")
