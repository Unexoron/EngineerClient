import { prefix } from "../../utils/utils"
const S32PacketConfirmTransaction = Java.type("net.minecraft.network.play.server.S32PacketConfirmTransaction");
///// RENDERING /////
// each setting will only effects 2 variables
// settingsgui and settingsguidata
import Settings from "../../config"
import { data } from "../../utils/data"

let testtitle1; let testtitle2; let testtitle4; let testtitle3 = [`&a5.21`]
const overlay1 = {render: null, title: testtitle1, truetitleDONTUSE: `clearsplitsgui`};
const overlay2 = {render: null, title: testtitle2, truetitleDONTUSE: `bosssplitsgui`};
const overlay3 = {render: null, title: testtitle3, truetitleDONTUSE: `purplepadtimergui`};
const overlay4 = {render: null, title: testtitle4, truetitleDONTUSE: `runpredictiongui`};
const overlayregister1 = register("renderOverlay", () => {
    Renderer.scale(data.clearsplitsguidata.scale);Renderer.drawStringWithShadow((overlay1.truetitleDONTUSE),data.clearsplitsguidata.x, data.clearsplitsguidata.y)}).unregister();
const overlayregister2 = register("renderOverlay", () => {
    Renderer.scale(data.bosssplitsguidata.scale);Renderer.drawStringWithShadow((overlay2.truetitleDONTUSE),data.bosssplitsguidata.x, data.bosssplitsguidata.y)}).unregister();
const overlayregister3 = register("renderOverlay", () => {
    Renderer.scale(data.purplepadtimerguidata.scale);Renderer.drawStringWithShadow((overlay3.truetitleDONTUSE),data.purplepadtimerguidata.x, data.purplepadtimerguidata.y)}).unregister();
const overlayregister4 = register("renderOverlay", () => {
    Renderer.scale(data.runpredictionguidata.scale);Renderer.drawStringWithShadow((overlay4.truetitleDONTUSE),data.runpredictionguidata.x, data.runpredictionguidata.y)}).unregister();
let guison
function updatetesttitles(){
    guison = true
    registerall()
    if (Settings.namedclearsplits) overlay1.truetitleDONTUSE = 
[` &aBlood Rush: 15.2s &0(&a-0.25s&0)\n &cBlood Camp: 62.2s &0(&c+1.25s&0)
 &dPortal: 8.2s &0(&c+4.45s&0)\n &6Boss Enter: 1m 25.2s &0(&a-15.25s&0)`];

    else overlay1.truetitleDONTUSE = 
[` &a15.2s &0(&a-0.25s&0)\n &c62.2s &0(&c+1.25s&0)
 &d8.2s &0(&c+4.45s&0)\n &61m 25.2s &0(&a-15.25s&0)`];

    if (Settings.namedbosssplits) {overlay2.truetitleDONTUSE = 
[` &aMaxor: 25.2s &0(&a-0.25s&0)\n &bStorm: 45.2s &0(&c+0.35s&0)
 &6Terminals: 36.2s &0(&c+7.35s&0)\n &eGoldor: 6.5s &0(&a-1.35s&0)
 &cNecron: 30.3s &0(&c+0.28s&0)\n &dAnimation: 4.2s &0(&a-0.35s&0)`]}

    else {overlay2.truetitleDONTUSE = 
[` &a25.2s &0(&a-0.25s&0)\n &b45.2s &0(&c+0.35s&0)
 &636.2s &0(&c+7.35s&0)\n &e6.5s &0(&a-1.35s&0)
 &c30.3s &0(&c+0.28s&0)\n &d4.2s &0(&a-0.35s&0)`]};

 if (Settings.runpredictionlongname) {
    overlay4.truetitleDONTUSE =
[` &3Run Prediction: 4m 18.6s &0(&a-1.35s&0)`]
 }

 if (!Settings.runpredictionlongname) {
    overlay4.truetitleDONTUSE =
[` &34m 18.6s &0(&a-1.35s&0)`]
 }

overlay3.truetitleDONTUSE = [`&a5.20`]
}

function updateuntesttitles(){
    unregisterall()
    overlay1.truetitleDONTUSE = overlay1.title
    overlay2.truetitleDONTUSE = overlay2.title
    overlay3.truetitleDONTUSE = overlay3.title
    overlay4.truetitleDONTUSE = overlay4.title
    guison = false
}
function registerall(){
    overlay1.render = true;overlayregister1.register();overlay2.render = true;overlayregister2.register()
    overlay3.render = true;overlayregister3.register();overlay4.render = true;overlayregister4.register()}; function unregisterall(){
    overlay1.render = false;overlayregister1.unregister();overlay2.render = false;overlayregister2.unregister()
    overlay3.render = false;overlayregister3.unregister();overlay4.render = false;overlayregister4.unregister()}
let anyguiopen
function guistuff() {
    if (Settings.clearsplitsgui.isOpen() || Settings.bosssplitsgui.isOpen() || Settings.purplepadtimergui.isOpen() || Settings.runpredictiongui.isOpen()) 
        updatetesttitles(); 
    else if (guison) updateuntesttitles();
    else {
        if (overlay1.render) {overlayregister1.register(); overlay1.truetitleDONTUSE = overlay1.title}
        if (overlay2.render) {overlayregister2.register(); overlay2.truetitleDONTUSE = overlay2.title}
        if (overlay3.render) {overlayregister3.register(); overlay3.truetitleDONTUSE = overlay3.title}
        if (overlay4.render) {overlayregister4.register(); overlay4.truetitleDONTUSE = overlay4.title}
    }
}
register("dragged", (dx, dy, x, y, bn) => {
    if (Settings.clearsplitsgui.isOpen() && bn != 2){
        data.clearsplitsguidata.x = (x / data.clearsplitsguidata.scale); data.clearsplitsguidata.y = (y / data.clearsplitsguidata.scale);data.save()}
    if (Settings.bosssplitsgui.isOpen() && bn != 2){
        data.bosssplitsguidata.x = (x / data.bosssplitsguidata.scale); data.bosssplitsguidata.y = (y / data.bosssplitsguidata.scale);data.save()}
    if (Settings.purplepadtimergui.isOpen() && bn != 2){
        data.purplepadtimerguidata.x = (x / data.purplepadtimerguidata.scale); data.purplepadtimerguidata.y = (y / data.purplepadtimerguidata.scale);data.save()}
    if (Settings.runpredictiongui.isOpen() && bn != 2){
        data.runpredictionguidata.x = (x / data.runpredictionguidata.scale); data.runpredictionguidata.y = (y / data.runpredictionguidata.scale);data.save()}
});register("scrolled", (x, y, dir) => {
    if (Settings.clearsplitsgui.isOpen()){
        if (dir == 1) data.clearsplitsguidata.scale += 0.05;else data.clearsplitsguidata.scale -= 0.05
        data.clearsplitsguidata.x = (x / data.clearsplitsguidata.scale); data.clearsplitsguidata.y = (y / data.clearsplitsguidata.scale);data.save()}
    if (Settings.bosssplitsgui.isOpen()){
        if (dir == 1) data.bosssplitsguidata.scale += 0.05; else data.bosssplitsguidata.scale -= 0.05
        data.bosssplitsguidata.x = (x / data.bosssplitsguidata.scale); data.bosssplitsguidata.y = (y / data.bosssplitsguidata.scale);data.save()}
    if (Settings.purplepadtimergui.isOpen()){
        if (dir == 1) data.purplepadtimerguidata.scale += 0.05; else data.purplepadtimerguidata.scale -= 0.05
        data.purplepadtimerguidata.x = (x / data.purplepadtimerguidata.scale); data.purplepadtimerguidata.y = (y / data.purplepadtimerguidata.scale);data.save()}
    if (Settings.runpredictiongui.isOpen()){
        if (dir == 1) data.runpredictionguidata.scale += 0.05; else data.runpredictionguidata.scale -= 0.05
        data.runpredictionguidata.x = (x / data.runpredictionguidata.scale); data.runpredictionguidata.y = (y / data.runpredictionguidata.scale);data.save()}
});register("guiMouseClick", (x, y, bn) => {
    if (Settings.clearsplitsgui.isOpen() && bn != 2) {
        data.clearsplitsguidata.x = (x / data.clearsplitsguidata.scale); data.clearsplitsguidata.y = (y / data.clearsplitsguidata.scale);data.save()} 
    if (Settings.clearsplitsgui.isOpen() && (bn == 2)) {
        data.clearsplitsguidata.x = Renderer.screen.getWidth() / 2;data.clearsplitsguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.clearsplitsguidata.scale = 1;data.save()}
    if (Settings.bosssplitsgui.isOpen() && bn != 2) {
        data.bosssplitsguidata.x = (x / data.bosssplitsguidata.scale); data.bosssplitsguidata.y = (y / data.bosssplitsguidata.scale);data.save()} 
    if (Settings.bosssplitsgui.isOpen() && (bn == 2)) {
        data.bosssplitsguidata.x = Renderer.screen.getWidth() / 2;data.bosssplitsguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.bosssplitsguidata.scale = 1;data.save()}
    if (Settings.purplepadtimergui.isOpen() && bn != 2) {
        data.purplepadtimerguidata.x = (x / data.purplepadtimerguidata.scale); data.purplepadtimerguidata.y = (y / data.purplepadtimerguidata.scale);data.save()} 
    if (Settings.purplepadtimergui.isOpen() && (bn == 2)) {
        data.purplepadtimerguidata.x = Renderer.screen.getWidth() / 2;data.purplepadtimerguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.purplepadtimerguidata.scale = 1;data.save()}
    if (Settings.runpredictiongui.isOpen() && bn != 2) {
        data.runpredictionguidata.x = (x / data.runpredictionguidata.scale); data.runpredictionguidata.y = (y / data.runpredictionguidata.scale);data.save()} 
    if (Settings.runpredictiongui.isOpen() && (bn == 2)) {
        data.runpredictionguidata.x = Renderer.screen.getWidth() / 2;data.runpredictionguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.runpredictionguidata.scale = 1;data.save()}
    });register("worldUnload", () => {
        overlayregister1.unregister();overlay1.render = false
        overlayregister2.unregister();overlay2.render = false
        overlayregister3.unregister();overlay3.render = false
        overlayregister4.unregister();overlay4.render = false
        worldloadd()})
///// /////


register("step", () => {
    guistuff()
    if (enterToggle) UpdateClear()
    if (inboss) UpdateBoss()
    if (startCheckToggle) hasrunstartedloop()
}).setFps(10)

function worldloadd(){
rushToggle = false;   rushStartTime = 0;   rushEndTime = 0;   ruslhgg = " "; rushlg = " "
campToggle = false;   campStartTime = 0;   campEndTime = 0;   camlpgg = ""; camplg = " "
portalToggle = false; portalStartTime = 0; portalEndTime = 0; portallgg = " "; portallg = " "
enterToggle = false;  enterStartTime = 0;  enterEndTime = 0;  enterlgg = " "; enterlg = " "
maxorToggle = false;     maxorStartTime = 0;     maxorEndTime = 0;     maxorSplitDisplay = 0;     maxorlgg = " "
stormToggle = false;     stormStartTime = 0;     stormEndTime = 0;     stormSplitDisplay = 0;     stormlgg = " "
goldorToggle = false;    goldorStartTime = 0;    goldorEndTime = 0;    goldorSplitDisplay = 0;    goldorlgg = " "
necronToggle = false;    necronStartTime = 0;    necronEndTime = 0;    necronSplitDisplay = 0;    necronlgg = " "
animationToggle = false; animationStartTime = 0; animationEndTime = 0; animationSplitDisplay = 0; animationlgg = " "
terminalsToggle = false; terminalsStartTime = 0; terminalsEndTime = 0; terminalsSplitDisplay = 0; terminalslgg = " "
totalTicks = 0;inboss = false; bloodCheckmark = false}let allsplitsaddedup
let rushToggle = false;   let rushStartTime = 0;   let rushEndTime = 0;   let rushSplitDisplay = 0;   let ruslhgg = " ";   
let campToggle = false;   let campStartTime = 0;   let campEndTime = 0;   let campSplitDisplay = 0;   let camlpgg = " ";   
let portalToggle = false; let portalStartTime = 0; let portalEndTime = 0; let portalSplitDisplay = 0; let portallgg = " "; 
let enterToggle = false;  let enterStartTime = 0;  let enterEndTime = 0;  let enterSplitDisplay = 0;  let enterlgg = " ";  
let maxorToggle = false;     let maxorSplitDisplay = `0s`;     let maxorStartTime = 0;     let maxorlag = 0;      let maxorEndTime = 0;     let maxorlgg = " "
let stormToggle = false;     let stormSplitDisplay = `0s`;     let stormStartTime = 0;     let stormlag = 0;      let stormEndTime = 0;     let stormlgg = " "
let goldorToggle = false;    let goldorSplitDisplay = `0s`;    let goldorStartTime = 0;    let goldorlag = 0;     let goldorEndTime = 0;    let goldorlgg = " "
let necronToggle = false;    let necronSplitDisplay = `0s`;    let necronStartTime = 0;    let necronlag= 0;      let necronEndTime = 0;    let necronlgg = " "
let animationToggle = false; let animationSplitDisplay = `0s`; let animationStartTime = 0; let animationlag = 0;  let animationEndTime = 0; let animationlgg = " "
let terminalsToggle = false; let terminalsSplitDisplay = `0s`; let terminalsStartTime = 0; let purpPadTicks = 0 ; let terminalsEndTime = 0; let terminalslgg = " "
let totalTicks = 0; let inboss = false; let bloodCheckmark = false; let purpPadDisplay;let enterSplitDisplayy = 0;function UpdateClear() {UpdateRunPrediction()
let bloodrush = ``;let camp = ``;let portal = ``;let enter = ``;let bloodmark = ` `
let rushlg = ` `;let camplg = ` `;let portallg = ` `;let enterlg = ` `
if (Settings.removebrackets) {bracketsforsplits1 = ` `; bracketsforsplits2 = ` `} else {bracketsforsplits1 = ` &0(`; bracketsforsplits2 = `&0)`}
entertimeforprediction = (parseFloat(Settings.rushtimeforprediction) + parseFloat(Settings.camptimeforprediction) + parseFloat(Settings.portaltimeforprediction))
if (rushToggle) rushSplitDisplay = `${(((Date.now() - rushStartTime) / 1000).toFixed(1))}s`
else{rushSplitDisplay = rushEndTime; if (rushEndTime > parseFloat(Settings.rushtimeforprediction)) {rushnp = `&c+`;rushnpp = `&c`} else {rushnp = `&a`;rushnpp = `&a`}
if (Settings.runprediction) rushlg = `${bracketsforsplits1}${rushnp}${(rushEndTime - Settings.rushtimeforprediction).toFixed(2)}s${bracketsforsplits2}`
ruslhgg = `${rushnpp}${Math.abs((rushEndTime - Settings.rushtimeforprediction).toFixed(2))}`}
if (campToggle) campSplitDisplay = `${(((Date.now() - campStartTime) / 1000).toFixed(1))}s`
else if (!rushToggle){campSplitDisplay = campEndTime;if (campEndTime > parseFloat(Settings.camptimeforprediction)) {campnpp = `&c+`;campnppp = `&c`} else {campnpp = `&a`;campnppp = `&a`}
if (Settings.runprediction) camplg = `${bracketsforsplits1}${campnpp}${(campEndTime - Settings.camptimeforprediction).toFixed(2)}s${bracketsforsplits2}`
camlpgg = `${campnppp}${Math.abs((campEndTime - Settings.camptimeforprediction).toFixed(2))}`}
if (portalToggle){portalSplitDisplay = `${(((Date.now() - portalStartTime) / 1000).toFixed(1))}s`}
else if (!rushToggle && !campToggle){portalSplitDisplay = portalEndTime; if (portalEndTime > parseFloat(Settings.portaltimeforprediction)) 
{portalnppp = `&c+`;portalnpppp = `&c`} else {portalnppp = `&a`; portalnpppp = `&a`}
if (Settings.runprediction) portallg = `${bracketsforsplits1}${portalnppp}${(portalEndTime - Settings.portaltimeforprediction).toFixed(2)}s${bracketsforsplits2}`
portallgg = `${portalnpppp}${Math.abs((portalEndTime - Settings.portaltimeforprediction).toFixed(2))}`}
if (enterToggle) enterSplitDisplay = (((Date.now() - rushStartTime) / 1000).toFixed(1))
else if (!rushToggle && !campToggle && !portalToggle){enterSplitDisplay = enterEndTime
if (enterEndTime > entertimeforprediction) {enternpp = `&c+`;enternppp = `&c`} else {enternpp = `&a`;enternppp = `&a`}
if (Settings.runprediction) enterlg = `${bracketsforsplits1}${enternpp}${Math.abs((enterEndTime - entertimeforprediction).toFixed(2))}s${bracketsforsplits2}`
enterlgg = `${enternppp}${Math.abs((enterEndTime - entertimeforprediction).toFixed(2))}`} 
if (Settings.bloodcheckmark) {if (bloodCheckmark) bloodmark = ` &a✔`; else bloodmark = ` `}
if (Settings.namedclearsplits) {bloodrush = " Blood Rush: "; camp = " Blood Camp: "; portal = " Portal: "; enter = " Boss Enter: "}
else {bloodrush = " "; camp = " "; portal = " "; enter = " "}
if (enterSplitDisplay >= 60) {enterSplitDisplayy = ((Math.floor((enterSplitDisplay / 60)).toFixed(0)) + "m " + ((((enterSplitDisplay % 60))).toFixed(1)).padStart(2,`0`) + "s")
} else {enterSplitDisplayy = (enterSplitDisplay + "s")}
if (Settings.clearsplits && Settings.onlytimelostgained)overlay1.title = 
`${ruslhgg}\n${camlpgg}\n${portallgg}\n${enterlgg}`; if (Settings.clearsplits && !Settings.onlytimelostgained) overlay1.title = `&a${bloodrush}${rushSplitDisplay}${rushlg}
&c${camp}${campSplitDisplay}${bloodmark}${camplg}\n&d${portal}${portalSplitDisplay}${portallg}\n&6${enter}${enterSplitDisplayy}${enterlg}`; else overlay1.title = ` `}
function UpdateBoss(){UpdateRunPrediction();
let maxorlg = ` `;let stormlg = ` `;let terminalslg = ` `;let goldorlg = ` `;let necronlg = ` `;let animationlg = ` `
if (Settings.removebrackets) {bracketsforsplits1 = ` `; bracketsforsplits2 = ` `} else {bracketsforsplits1 = ` &0(`; bracketsforsplits2 = `&0)`}
if (maxorToggle) maxorSplitDisplay = `${(totalTicks / 20).toFixed(2)}s`
else {maxorSplitDisplay = maxorEndTime;if (maxorEndTime > parseFloat(Settings.maxortimeforprediction)) {maxornp = `&c+`;maxornpp = `&c`} else {maxornp = `&a`;maxornpp = `&a`}
if (Settings.runprediction) maxorlg = `${bracketsforsplits1}${maxornp}${(maxorEndTime - Settings.maxortimeforprediction).toFixed(2)}s${bracketsforsplits2}` 
maxorlgg = `${maxornpp}${Math.abs((maxorEndTime - Settings.maxortimeforprediction).toFixed(2))}`} 
if (stormToggle) {stormSplitDisplay = `${(totalTicks / 20).toFixed(2)}s`
purpPadTicks = ((((totalTicks) * -1) + 644) / 20).toFixed(2);purpPadDisplay = `&a${purpPadTicks}`} 
else if (!maxorToggle) {stormSplitDisplay = stormEndTime;if (stormEndTime > parseFloat(Settings.stormtimeforprediction)) {stormnp = `&c+`;stormnpp = `&c`} else {stormnp = `&a`;stormnpp = `&a`}
if (Settings.runprediction) stormlg = `${bracketsforsplits1}${stormnp}${(stormEndTime - Settings.stormtimeforprediction).toFixed(2)}s${bracketsforsplits2}`
stormlgg = `${stormnpp}${Math.abs((stormEndTime - Settings.stormtimeforprediction).toFixed(2))}`} 
if (terminalsToggle) terminalsSplitDisplay = `${((Date.now() - terminalsStartTime) / 1000).toFixed(2)}s`;else if (!maxorToggle && !stormToggle){
terminalsSplitDisplay = terminalsEndTime;if (terminalsEndTime > parseFloat(Settings.terminalstimeforprediction)) {terminalsnp = `&c+`;terminalsnpp = `&c`} else {terminalsnp = `&a`;terminalsnpp = `&a`}
if (Settings.runprediction) terminalslg = `${bracketsforsplits1}${terminalsnp}${(terminalsEndTime - parseFloat(Settings.terminalstimeforprediction)).toFixed(2)}s${bracketsforsplits2}`
terminalslgg = `${terminalsnpp}${Math.abs((terminalsEndTime - Settings.terminalstimeforprediction).toFixed(2))}`} 
if (goldorToggle) goldorSplitDisplay = `${(totalTicks / 20).toFixed(2)}s`
else if (!maxorToggle && !stormToggle && !terminalsToggle){goldorSplitDisplay = goldorEndTime;
if (goldorEndTime > parseFloat(Settings.goldortimeforprediction)) {goldornp = `&c+`;goldornpp = `&c`} else {goldornp = `&a`;goldornpp = `&a`}
if (Settings.runprediction) goldorlg = `${bracketsforsplits1}${goldornp}${(goldorEndTime - Settings.goldortimeforprediction).toFixed(2)}s${bracketsforsplits2}`
goldorlgg = `${goldornpp}${Math.abs((goldorEndTime - Settings.goldortimeforprediction).toFixed(2))}`}
if (necronToggle) necronSplitDisplay = `${(totalTicks / 20).toFixed(2)}s`
else if (!maxorToggle && !stormToggle && !terminalsToggle && !goldorToggle){necronSplitDisplay = necronEndTime;
if (necronEndTime > parseFloat(Settings.necrontimeforprediction)) {necronnp = `&c+`;necronnpp = `&c`} else {necronnp = `&a`; necronnpp = `&a`}
if (Settings.runprediction) necronlg = `${bracketsforsplits1}${necronnp}${(necronEndTime - Settings.necrontimeforprediction).toFixed(2)}s${bracketsforsplits2}`
necronlgg = `${necronnpp}${Math.abs((necronEndTime - Settings.necrontimeforprediction).toFixed(2))}`}
if (animationToggle) animationSplitDisplay = `${(totalTicks / 20).toFixed(2)}s`
else if (!maxorToggle && !stormToggle && !terminalsToggle && !goldorToggle && !necronToggle){animationSplitDisplay = animationEndTime;
if (animationEndTime > parseFloat(Settings.animationtimeforprediction)) {animationnp = `&c+`; animationnpp = `&c`;} else {animationnp = `&a`; animationnpp = `&a`}
if (Settings.runprediction) animationlg = `${bracketsforsplits1}${animationnp}${(animationEndTime - Settings.animationtimeforprediction).toFixed(2)}s${bracketsforsplits2}`
animationlgg = `${animationnpp}${Math.abs((animationEndTime - Settings.animationtimeforprediction).toFixed(2))}`}
if (Settings.namedbosssplits) {maxor = " Maxor: "; storm = " Storm: "; terminals = " Terminals: "; goldor = " Goldor: "; necron = " Necron: "; animationnn = " Animation: "}
else {maxor = " "; storm = " "; terminals = " "; goldor = " "; necron = " "; animationnn = " "}
if (Settings.bosssplits && Settings.onlytimelostgained)overlay2.title = 
`${maxorlgg}\n${stormlgg}\n${terminalslgg}\n${goldorlgg}\n${necronlgg}\n${animationlgg}`
if (Settings.bosssplits && !Settings.onlytimelostgained) overlay2.title = `&a${maxor}&r&a${maxorSplitDisplay} ${maxorlg}\n&b${storm}&r&b${stormSplitDisplay} ${stormlg}\n&6${terminals}&r&6${terminalsSplitDisplay} ${terminalslg}
&e${goldor}&r&e${goldorSplitDisplay} ${goldorlg}\n&c${necron}&r&c${necronSplitDisplay} ${necronlg}\n&d${animationnn}&r&d${animationSplitDisplay} ${animationlg}`; else overlay2.title = ` `
if (purpPadTicks < 6 && purpPadTicks > 0 && Settings.purplepadtimer) {overlay3.render = true;overlay3.title = purpPadDisplay} else {overlay3.render = false; overlayregister3.unregister()}
}function UpdateRunPrediction(){if (Settings.removebrackets) {bracketsforsplits1 = ` `; bracketsforsplits2 = ` `} else {bracketsforsplits1 = ` &0(`; bracketsforsplits2 = `&0)`}
if (Settings.runpredictionlongname) {splitsthing = " Run Prediction: "} else splitsthing = " ";allsetsplitsaddedup = ((    
parseFloat(Settings.rushtimeforprediction) + parseFloat(Settings.camptimeforprediction) + parseFloat(Settings.portaltimeforprediction) + 
parseFloat(Settings.maxortimeforprediction) + parseFloat(Settings.stormtimeforprediction) + parseFloat(Settings.terminalstimeforprediction) + 
parseFloat(Settings.goldortimeforprediction) + parseFloat(Settings.necrontimeforprediction) + parseFloat(Settings.animationtimeforprediction)).toFixed(1))
if (rushEndTime > 0) split1 = rushEndTime; else split1 = parseFloat(Settings.rushtimeforprediction)
if (campEndTime > 0) split2 = campEndTime; else split2 = parseFloat(Settings.camptimeforprediction)
if (portalEndTime > 0) split3 = portalEndTime; else split3 = parseFloat(Settings.portaltimeforprediction)
if (maxorEndTime > 0) split4 = maxorEndTime; else split4 = parseFloat(Settings.maxortimeforprediction)
if (stormEndTime > 0) split5 = stormEndTime; else split5 = parseFloat(Settings.stormtimeforprediction)
if (terminalsEndTime > 0) split6 = terminalsEndTime; else split6 = parseFloat(Settings.terminalstimeforprediction)
if (goldorEndTime > 0) split7 = goldorEndTime; else split7 = parseFloat(Settings.goldortimeforprediction)
if (necronEndTime > 0) split8 = necronEndTime; else split8 = parseFloat(Settings.necrontimeforprediction)
if (animationEndTime > 0) split9 = animationEndTime; else split9 = parseFloat(Settings.animationtimeforprediction)
allsplitsaddedup = (parseFloat(split1) + parseFloat(split2) + parseFloat(split3) + parseFloat(split4) + parseFloat(split5) + parseFloat(split6) + parseFloat(split7) + parseFloat(split8) + parseFloat(split9))
if (allsplitsaddedup > allsetsplitsaddedup) splitsnp = `&c+`; else splitsnp = `&a`
runpredictionDisplay = `${bracketsforsplits1}${splitsnp}${(allsplitsaddedup - allsetsplitsaddedup).toFixed(2)}s${bracketsforsplits2}`
if (allsplitsaddedup == allsetsplitsaddedup) runpredictionDisplay = ` `
if (allsplitsaddedup >= 60 && Settings.runprediction) overlay4.title = `&3${splitsthing}&6${(Math.floor((allsplitsaddedup) / 60)).toFixed(0)}m ${((((allsplitsaddedup) % 60) / 100).toFixed(4) * 100).toFixed(1)}s ${runpredictionDisplay}`
else if (Settings.runprediction) overlay4.title = `&3${splitsthing}&6${allsplitsaddedup}s ${runpredictionDisplay}`
if (!Settings.runprediction) overlay4.title = ` `}function hasrunstartedloop() {const lines = Scoreboard.getLines(false);lines.map((line) => {
if ((line.getName().removeFormatting().replace(/[^\x00-\x7F]/g, "")).includes("Time Elapsed")) {startCheckToggle = false;rushStartTime = Date.now();enterStartTime = Date.now()
overlay1.render = true;overlay4.render = true;enterToggle = true;rushToggle = true;if (Settings.onlytimelostgained){rushSplitDisplay = " " ;campSplitDisplay = " " 
portalSplitDisplay = " " ;enterSplitDisplay = " " }}});}

// blood rush start //
let startCheckToggle = false
register("chat", () => {
    startCheckToggle = true
    setTimeout(() => startCheckToggle = false, 4000);
}).setCriteria("Starting in 1 second.");

const bloodStartMessage = [
    "[BOSS] The Watcher: Congratulations, you made it through the Entrance.",
    "[BOSS] The Watcher: Ah, you've finally arrived.",
    "[BOSS] The Watcher: Ah, we meet again...",
    "[BOSS] The Watcher: So you made it this far... interesting.",
    "[BOSS] The Watcher: I'm starting to get tired of seeing you around here...",
    "[BOSS] The Watcher: Oh.. hello?",
    "[BOSS] The Watcher: Things feel a little more roomy now, eh?",]
// camp start //
register("chat", (message) => {
    if (!bloodStartMessage.includes(message)) return
    rushToggle = false
    if (rushStartTime == 0) {
        rushEndTime = ((Date.now() - Date.now()) / 1000).toFixed(1)
    } if (rushStartTime > 0) {
        rushEndTime = ((Date.now() - rushStartTime) / 1000).toFixed(1)
    }
    campToggle = true
    campStartTime = (Date.now())
}).setCriteria("${message}")
// watcher spawned //
register("chat", () => {
    bloodCheckmark = true
}).setCriteria("[BOSS] The Watcher: That will be enough for now.")
// portal start //
register("chat", () => {
    campToggle = false
    campEndTime = ((Date.now() - campStartTime) /1000).toFixed(1)
    portalToggle = true
    portalStartTime = (Date.now())
}).setCriteria("[BOSS] The Watcher: You have proven yourself. You may pass.")

// boss start //
// maxor start //
register("chat", () => {
    enterToggle = false
    enterEndTime = ((Date.now() - enterStartTime) /1000).toFixed(1)
    portalToggle = false
    portalEndTime = ((Date.now() - portalStartTime) /1000).toFixed(1)
    overlay2.render = true
    inboss = true
    totalTicks = 0
    maxorToggle = true
    maxorStartTime = Date.now()
    UpdateClear()
    if (Settings.onlytimelostgained){
    maxorSplitDisplay = " " 
    stormSplitDisplay = " " 
    terminalsSplitDisplay = " " 
    goldorSplitDisplay = " " 
    necronSplitDisplay = " " 
    animationSplitDisplay = " " }
}).setCriteria("[BOSS] Maxor: WELL! WELL! WELL! LOOK WHO'S HERE!")
// storm start //
register("chat", () => {
    maxorToggle = false
    maxorSplitDisplay = (totalTicks / 20).toFixed(2)
    maxorEndTime = (totalTicks / 20).toFixed(2)
    prefix(`you lost ${((((Date.now() - maxorStartTime) - (totalTicks * 50)) / 1000).toFixed(2))} to server lag in maxor!`)
    totalTicks = 0
    stormToggle = true
    stormStartTime = Date.now()
}).setCriteria("[BOSS] Storm: Pathetic Maxor, just like expected.")
// terminals start //
register("chat", () => {
    stormToggle = false
    stormSplitDisplay = (totalTicks / 20).toFixed(2)
    stormEndTime = (totalTicks / 20).toFixed(2)
    totalTicks = 0
    terminalsToggle = true
    terminalsStartTime = Date.now()
}).setCriteria("[BOSS] Goldor: Who dares trespass into my domain?")
// goldor start //
register("chat", () => {
    terminalsToggle = false
    terminalsEndTime = ((Date.now() - terminalsStartTime) /1000).toFixed(2)
    totalTicks = 0
    goldorToggle = true
    goldorStartTime = Date.now()
}).setCriteria("The Core entrance is opening!")
// necron start //
register("chat", () => {
    goldorToggle = false
    goldorSplitDisplay = (totalTicks / 20).toFixed(2)
    goldorEndTime = (totalTicks / 20).toFixed(2)
    totalTicks = 0
    necronToggle = true
    necronStartTime = Date.now()
}).setCriteria(/\[BOSS\] Necron: (Finally, I heard so much about you.|You went further than any human before).*?/)
// animation start //
register("chat", () => {
    necronToggle = false
    necronSplitDisplay = (totalTicks / 20).toFixed(2)
    necronEndTime = (totalTicks / 20).toFixed(2)
    totalTicks = 0
    animationToggle = true
    animationStartTime = Date.now()
}).setCriteria("[BOSS] Necron: All this, for nothing...")
const necronEndMessage = [
    "                        The Catacombs - Floor VII",
    "                                  Master Mode - Floor VII",
]
register("chat", (message) => {
    if (!necronEndMessage.includes(message)) return
    animationToggle = false
    animationEndTime = (totalTicks / 20).toFixed(2)
    prefix(`&6The server lost &3${(((Date.now() - maxorStartTime) / 1000) - (allsplitsaddedup)).toFixed(2)} &6seconds due to server lag in boss`)
}).setCriteria("${message}")


register('packetReceived', () => {
    totalTicks++
}).setFilteredClass(S32PacketConfirmTransaction)

register("command", () => {
    overlay1.render = true
    overlay2.render = true
    overlay3.render = true
    overlay4.render = true
    setTimeout(() => {
        if (inboss) {
        overlay3.render = false
        overlayregister3.unregister()
        } if (!inboss && enterToggle) {
        overlay2.render = false
        overlayregister2.unregister()
        overlay3.render = false
        overlayregister3.unregister()
        } else {
        overlay1.render = false
        overlayregister1.unregister()
        overlay2.render = false
        overlayregister2.unregister()
        overlay3.render = false
        overlayregister3.unregister()
        overlay4.render = false
        overlayregister4.unregister()
        }
    }, 2000)
}).setName("testsplitpos");

register("command", () => {
    if (enterToggle) {
        overlay1.render = true
        overlay4.render = true
    } if (inboss) {
        overlay2.render = true
        overlay4.render = true
    }
}).setName("showrightsplits");