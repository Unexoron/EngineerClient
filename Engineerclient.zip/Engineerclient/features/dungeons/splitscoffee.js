// import RenderLibV2 from "../../../RenderLibV2"
// import prefix from "../../utils/utils"
// ///// RENDERING /////
// // each setting will only effects 2 variables
// // settingsgui and settingsguidata
// import Settings from "../../config"
// import { data } from "../../utils/data"
// let testtitle1 = [`&63.15 Blocks/s`];let testtitle2 = [`test`]
// const overlay1 = {render: null, title: "gb8yuwe2983th2398", started: null, truetitleDONTUSE: `witherspeedgui`};
// const overlayregister1 = register("renderOverlay", () => {
//     Renderer.scale(data.witherspeedguidata.scale);Renderer.drawStringWithShadow((overlay1.truetitleDONTUSE),data.witherspeedguidata.x, data.witherspeedguidata.y)}).unregister();
// let gui1on
// function registerall(){overlay1.render = true;overlayregister1.register()}; 
// function unregisterall(){overlay1.render = false;overlayregister1.unregister()}
// register("step", () => {
//     if (!Settings.witherspeed) return
//     if (Settings.witherspeedgui.isOpen()) registerall();if (overlay1.render) { overlayregister1.register();  
//         if (Settings.witherspeedgui.isOpen()) {overlay1.truetitleDONTUSE = testtitle1;gui1on = true}
//         else if (!Settings.witherspeedgui.isOpen() && gui1on) {unregisterall();overlay1.truetitleDONTUSE = " "; gui1on = false}
//         else overlay1.truetitleDONTUSE = overlay1.title}
// }).setFps(10);register("dragged", (dx, dy, x, y, bn) => {
//     if (Settings.witherspeedgui.isOpen() && bn != 2){
//         data.witherspeedguidata.x = (x / data.witherspeedguidata.scale); data.witherspeedguidata.y = (y / data.witherspeedguidata.scale);data.save()}
// });register("scrolled", (x, y, dir) => {
//     if (Settings.witherspeedgui.isOpen()){
//         if (dir == 1) data.witherspeedguidata.scale += 0.05;else data.witherspeedguidata.scale -= 0.05
//         data.witherspeedguidata.x = (x / data.witherspeedguidata.scale); data.witherspeedguidata.y = (y / data.witherspeedguidata.scale);data.save()}
//     if (Settings.sectiontimesgui.isOpen()){
//         if (dir == 1) data.sectiontimesguidata.scale += 0.05; else data.sectiontimesguidata.scale -= 0.05
//         data.sectiontimesguidata.x = (x / data.sectiontimesguidata.scale); data.sectiontimesguidata.y = (y / data.sectiontimesguidata.scale);data.save()}
// });register("guiMouseClick", (x, y, bn) => {
//     if (Settings.witherspeedgui.isOpen() && bn != 2) {
//         data.witherspeedguidata.x = (x / data.witherspeedguidata.scale); data.witherspeedguidata.y = (y / data.witherspeedguidata.scale);data.save()} 
//     if (Settings.witherspeedgui.isOpen() && (bn == 2)) {
//         data.witherspeedguidata.x = Renderer.screen.getWidth() / 2;data.witherspeedguidata.y = Renderer.screen.getHeight() / 2 + 10
//         data.witherspeedguidata.scale = 1;data.save()}
//     });register("worldUnload", () => {overlayregister1.unregister();overlay1.render = false})
//     register("command", () => {overlay1.render = true
//         setTimeout(() => {overlay1.render = false;overlayregister1.unregister()}, 2000)
//     }).setName("testwitherspeedpos");
// ///// /////



// let inboss = true
// register("chat", () => {
//     inboss = true
// }).setCriteria("[BOSS] Maxor: WELL! WELL! WELL! LOOK WHO'S HERE!")
// const necronStartMessage = [
//     "[BOSS] Necron: Finally, I heard so much about you. The Eye likes you very much.",
//     "[BOSS] Necron: You went further than any human before, congratulations.",
// ]
// register("chat", (message) => {
//     if (!necronStartMessage.includes(message)) return
//     inboss = false
// }).setCriteria("${message}")







// const EntityArmorStand = Java.type("net.minecraft.entity.item.EntityArmorStand");
// const S17PacketEntityLookMove = Java.type("net.minecraft.network.play.server.S14PacketEntity$S17PacketEntityLookMove");

// const trigger = register("packetReceived", packet => {
// 	const mcEntity = packet.func_149065_a(World.getWorld());
// 	if (!mcEntity) return;
// 	console.log(mcEntity);
// 	// const itemStack = packet.func_149390_c();
// 	// if (!itemStack) return;
// 	// const item = new Item(itemStack);
// 	// if (item.getID() !== 397) return;
// 	// const nbtObject = item.getItemNBT()?.toObject();
// 	// if (!nbtObject) return;
// 	// const textures = nbtObject.tag?.SkullOwner?.Properties?.textures?.[0]?.Value;
// 	// if (!textures) return;
// 	// ChatLib.chat(textures);
// }).setFilteredClass(S17PacketEntityLookMove).unregister();

// export function enable() {
// 	trigger.register();
// }

// export function disable() {
// 	trigger.unregister();
// }

// export default { enable, disable };

// let witherx1 = 0
// let withery1 = 0
// let witherz1 = 0
// let lastWitherMovement = 0

// const overlayTriggerWitherHitboxes = register("renderWorld", () => {
//     World.getAllEntitiesOfType(net.minecraft.entity.boss.EntityWither).forEach(entity => {
//         if (entity.getMotionX() == 0) {
//             x1 = witherx1
//         } else {
//             x1 = (entity.getRenderX() + entity.getMotionX())
//             witherx1 = (entity.getRenderX() + entity.getMotionX())
//         } if (entity.getMotionY() == 0) {
//             y1 = withery1
//         } else {
//             y1 = (entity.getRenderY() + entity.getMotionY())
//             withery1 = (entity.getRenderY() + entity.getMotionY())
//         } if (entity.getMotionZ() == 0) {
//             z1 = witherz1
//         } else {
//             z1 = (entity.getRenderZ() + entity.getMotionZ())
//             witherz1 = (entity.getRenderZ() + entity.getMotionZ())
//         }
//         const width = entity.getWidth()
//         const height = entity.getHeight()
//         RenderLibV2.drawEspBoxV2(x1, y1, z1, width, height, width, 0, 1, 0.8, 1, false)
//     })
// }).unregister();

// register('tick', () => {
//     if (Settings.witherspeed && inboss) {
//         World.getAllEntitiesOfType(net.minecraft.entity.boss.EntityWither).forEach(entity => {
//             prefix(entity.isWet()) 
//             prefix(entity.getHeight())
//             prefix(entity.isEating())
//             prefix(entity.isImmuneToFire())
//             entity.isEating()
//             entity.hasNoClip().valueOf.apply.
//             entity.isOnGround()
            
            
//             overlayTriggerWitherHitboxes.register()
//             if (entity.getMotionX() !== 0 && entity.getMotionZ() !== 0 && !Settings.witherspeedy) {
//                 overlay1.title = ((Math.sqrt((entity.getMotionX())**2 + (entity.getMotionZ())**2)) * 50).toFixed(3)
//             } if (entity.getMotionX() !== 0 && entity.getMotionZ() !== 0 && Settings.witherspeedy) {
//                 overlay1.title = ((Math.sqrt((entity.getMotionX())**2 + (entity.getMotionY())**2 + (entity.getMotionZ())**2)) * 50).toFixed(3)
//             }
//         })
//     }
// });












/*
register('tick', () => {
    World.getAllEntitiesOfType(net.minecraft.entity.boss.EntityWither).forEach(entity => {
        ChatLib.chat(Math.sqrt((entity.getX() - witherx1)^2 + (entity.getY() - withery1)^2 + (entity.getZ() - witherz1)^2).toFixed(3))
        lastWitherMovement = (Math.sqrt((entity.getX() - witherx1)^2 + (entity.getY() - withery1)^2 + (entity.getZ() - witherz1)^2))
        witherx1 = entity.getX()
        withery1 = entity.getY()
        witherz1 = entity.getZ()
    })
});



register("step", () => {
    World.getAllEntitiesOfType(net.minecraft.entity.boss.EntityWither).forEach(entity => {
        ChatLib.chat((Math.sqrt((entity.getRenderX() - witherx1)**2 + (entity.getRenderY() - withery1)**2 + (entity.getRenderZ() - witherz1)**2) + lastWitherMovement) / 2)
        lastWitherMovement = (Math.sqrt((entity.getRenderX() - witherx1)**2 + (entity.getRenderY() - withery1)**2 + (entity.getRenderZ() - witherz1)**2))
        witherx1 = entity.getRenderX()
        withery1 = entity.getRenderY()
        witherz1 = entity.getRenderZ()
    })
}).setFps(4);
*/


