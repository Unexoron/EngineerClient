const S32PacketConfirmTransaction = Java.type("net.minecraft.network.play.server.S32PacketConfirmTransaction");
///// RENDERING /////
// each setting will only effects 2 variables
// settingsgui and settingsguidata
import Settings from "../../config"
import { data } from "../../utils/data"
let testtitle1 = [
`&3Intro Animation: &b33.2s
&eFirst Crush: &b&l1.35&r&bs
&cFirst DPS: &b&l0.25&r&bs
&eSecond Crush: &b&l2.76&r&bs
&cSecond DPS: &b&l0.16&r&bs
&3Ending Animation: &b5.20s`]
let testtitle2 = [
`&c4.2s`];
const overlay1 = {render: null, title: testtitle1, truetitleDONTUSE: `p2gui`};
const overlay2 = {render: null, title: testtitle2, truetitleDONTUSE: `stormcountdowngui`};
const overlayregister1 = register("renderOverlay", () => {
    Renderer.scale(data.p2guidata.scale);Renderer.drawStringWithShadow((overlay1.truetitleDONTUSE),data.p2guidata.x, data.p2guidata.y)}).unregister();
const overlayregister2 = register("renderOverlay", () => {
    Renderer.scale(data.stormcountdownguidata.scale);Renderer.drawStringWithShadow((overlay2.truetitleDONTUSE),data.stormcountdownguidata.x, data.stormcountdownguidata.y)}).unregister();
let gui1on; let gui2on
function registerall(){
    overlay1.render = true;overlayregister1.register();overlay2.render = true;overlayregister2.register()}; function unregisterall(){
    overlay1.render = false;overlayregister1.unregister();overlay2.render = false;overlayregister2.unregister()}
register("step", () => {
    if (Settings.p2gui.isOpen()) registerall();if (overlay1.render) { overlayregister1.register();  
        if (Settings.p2gui.isOpen()) {overlay1.truetitleDONTUSE = testtitle1;gui1on = true}
        else if (!Settings.p2gui.isOpen() && gui1on) {unregisterall();overlay1.truetitleDONTUSE = " "; gui1on = false}
        else overlay1.truetitleDONTUSE = overlay1.title}
    if (Settings.stormcountdowngui.isOpen()) registerall();if (overlay2.render) { overlayregister2.register(); 
        if (Settings.stormcountdowngui.isOpen()) {overlay2.truetitleDONTUSE = testtitle2;gui2on = true}
        else if (!Settings.stormcountdowngui.isOpen() && gui2on) {unregisterall();overlay2.truetitleDONTUSE = " "; gui2on = false}
        else overlay2.truetitleDONTUSE = overlay2.title}
}).setFps(10);register("dragged", (dx, dy, x, y, bn) => {
    if (Settings.p2gui.isOpen() && bn != 2){
        data.p2guidata.x = (x / data.p2guidata.scale); data.p2guidata.y = (y / data.p2guidata.scale);data.save()}
    if (Settings.stormcountdowngui.isOpen() && bn != 2){
        data.stormcountdownguidata.x = (x / data.stormcountdownguidata.scale); data.stormcountdownguidata.y = (y / data.stormcountdownguidata.scale);data.save()}
});register("scrolled", (x, y, dir) => {
    if (Settings.p2gui.isOpen()){
        if (dir == 1) data.p2guidata.scale += 0.05;else data.p2guidata.scale -= 0.05
        data.p2guidata.x = (x / data.p2guidata.scale); data.p2guidata.y = (y / data.p2guidata.scale);data.save()}
    if (Settings.stormcountdowngui.isOpen()){
        if (dir == 1) data.stormcountdownguidata.scale += 0.05; else data.stormcountdownguidata.scale -= 0.05
        data.stormcountdownguidata.x = (x / data.stormcountdownguidata.scale); data.stormcountdownguidata.y = (y / data.stormcountdownguidata.scale);data.save()}
});register("guiMouseClick", (x, y, bn) => {
    if (Settings.p2gui.isOpen() && bn != 2) {
        data.p2guidata.x = (x / data.p2guidata.scale); data.p2guidata.y = (y / data.p2guidata.scale);data.save()} 
    if (Settings.p2gui.isOpen() && (bn == 2)) {
        data.p2guidata.x = Renderer.screen.getWidth() / 2;data.p2guidata.y = Renderer.screen.getHeight() / 2 + 10
        data.p2guidata.scale = 1;data.save()}
    if (Settings.stormcountdowngui.isOpen() && bn != 2) {
        data.stormcountdownguidata.x = (x / data.stormcountdownguidata.scale); data.stormcountdownguidata.y = (y / data.stormcountdownguidata.scale);data.save()} 
    if (Settings.stormcountdowngui.isOpen() && (bn == 2)) {
        data.stormcountdownguidata.x = Renderer.screen.getWidth() / 2;data.stormcountdownguidata.y = Renderer.screen.getHeight() / 2 + 10
        data.stormcountdownguidata.scale = 1;data.save()}
    });register("worldUnload", () => {
        overlayregister1.unregister();overlay1.render = false
        overlayregister2.unregister();overlay2.render = false
    worldloadd()})
    register("command", () => {overlay1.render = true;overlay2.render = true
        setTimeout(() => {overlay1.render = false;overlayregister1.unregister()
        overlay2.render = false;overlayregister2.unregister()}, 2000)
    }).setName("testp2pos");
///// /////

function worldloadd(){
    stormreport = [``]
    lightningTicks = 0
    stormticks = 0
    firstmoveticks = 0
    firstmovetickstoggle = false
    stormlightningtoggle1 = false
    stormlightningtoggle2 = false
    
    instorm = false
    firststormdisplay = ` `
    firststormtoggle = false
    firststormendtime = 0
    
    firstcrushdisplay = ` `
    firstcrushhappened = false
    firstcrushtoggle = false
    firstcrushendtime = 0
    
    firstdpsdisplay = ` `
    firstdpshappened = false
    firstdpstoggle = false
    firstdpsendtime = 0
    
    secondcrushdisplay = ` `
    secondcrushhappened = false
    secondcrushtoggle = false
    secondcrushendtime = 0
    
    seconddpsdisplay = ` `
    seconddpshappened = false
    seconddpstoggle = false
    seconddpsendtime = 0
    
    secondstormdisplay = ` `
    secondstormtoggle = false
    secondstormendtime = 0
}
let stormreport = [``]
let lightningTicks
let stormticks
let firstmoveticks
let firstmovetickstoggle = false
let stormlightningtoggle1 = false
let stormlightningtoggle2 = false

let instorm = false
let firststormdisplay = ` `
let firststormtoggle = false
let firststormendtime

let firstcrushdisplay = ` `
let firstcrushhappened = false
let firstcrushtoggle = false
let firstcrushendtime

let firstdpsdisplay = ` `
let firstdpshappened = false
let firstdpstoggle = false
let firstdpsendtime

let secondcrushdisplay = ` `
let secondcrushhappened = false
let secondcrushtoggle = false
let secondcrushendtime

let seconddpsdisplay = ` `
let seconddpshappened = false
let seconddpstoggle = false
let seconddpsendtime

let secondstormdisplay = ` `
let secondstormtoggle = false
let secondstormendtime


function UpdateStormCountdown1(){
        if (lightningTicks > 134) {
            overlay2.render = false; overlayregister2.unregister(); stormlightningtoggle1 = false} else{
        overlay2.render = true
        overlay2.title = `&c${(Math.abs((lightningTicks - 140)/20)).toFixed(1)}`}
}

function UpdateStormCountdown2(){
        if (lightningTicks > 14) {overlay2.render = false; overlayregister2.unregister(); stormlightningtoggle2 = false} else{
        overlay2.render = true
        overlay2.title = `&4${(((Math.abs((lightningTicks - 10)/20)).toFixed(1)))}`}
}

function UpdateStorm(){
    if (Settings.p2info) {
        if (Settings.p2names) {
            if (firstmovetickstoggle) {if (firstmoveticks > 140){
                firstmovetickstoggle = false; 
                firststormtoggle = false
                firstcrushtoggle = true
                firststormendtime = (stormticks / 20).toFixed(2)
                stormticks = 0
            }}
            if (firststormtoggle) firststormdisplay = `&3Intro Animation: &b${((Math.abs(stormticks / 20)).toFixed(2))}s`
            if (firstcrushtoggle) firstcrushdisplay = `&eFirst Crush: &b&l${((Math.abs(stormticks / 20)).toFixed(2))}&r&bs`
            if (firstdpstoggle) firstdpsdisplay = `&cFirst DPS: &b&l${((Math.abs(stormticks / 20)).toFixed(2))}&r&bs`
            if (secondcrushtoggle) secondcrushdisplay = `&eSecond Crush: &b&l${((Math.abs(stormticks / 20)).toFixed(2))}&r&bs`
            if (seconddpstoggle) seconddpsdisplay = `&cSecond DPS: &b&l${((Math.abs(stormticks / 20)).toFixed(2))}&r&bs`
            if (secondstormtoggle) secondstormdisplay = `&3Ending Animation: &b${((Math.abs(stormticks / 20)).toFixed(2))}s`
            overlay1.title = 
        `&a${firststormdisplay}
${firstcrushdisplay}
${firstdpsdisplay}
${secondcrushdisplay}
${seconddpsdisplay}
${secondstormdisplay}`
        } else {
            if (firstmovetickstoggle) {if (firstmoveticks > 140){
                firstmovetickstoggle = false; 
                firststormtoggle = false
                firstcrushtoggle = true
                firststormendtime = (stormticks / 20).toFixed(2)
                stormticks = 0
            }}
            if (firststormtoggle) firststormdisplay = `&a${((Math.abs(stormticks / 20)).toFixed(2))}`
            if (firstcrushtoggle) firstcrushdisplay = `&6${((Math.abs(stormticks / 20)).toFixed(2))}`
            if (firstdpstoggle) firstdpsdisplay = `&c${((Math.abs(stormticks / 20)).toFixed(2))}`
            if (secondcrushtoggle) secondcrushdisplay = `&6${((Math.abs(stormticks / 20)).toFixed(2))}`
            if (seconddpstoggle) seconddpsdisplay = `&c${((Math.abs(stormticks / 20)).toFixed(2))}`
            if (secondstormtoggle) secondstormdisplay = `&a${((Math.abs(stormticks / 20)).toFixed(2))}`
            overlay1.title = 
        `&a${firststormdisplay}
        ${firstcrushdisplay}
        ${firstdpsdisplay}
        ${secondcrushdisplay}
        ${seconddpsdisplay}
        ${secondstormdisplay}`
        }
    }
}


register('packetReceived', () => {
    if (!instorm) return
    lightningTicks++
    stormticks++
    firstmoveticks++
}).setFilteredClass(S32PacketConfirmTransaction)

register("step", () => {
    if (stormlightningtoggle1 && Settings.stormcountdown) UpdateStormCountdown1()
    if (stormlightningtoggle2 && Settings.stormcountdown) {UpdateStormCountdown2()}
    if (instorm && Settings.p2gui) {UpdateStorm()}
}).setFps(10)

register("chat", () => {
    lightningTicks = 0
    stormlightningtoggle1 = true
}).setCriteria("[BOSS] Storm: The power of lightning is quite phenomenal. A single strike can vaporize a person whole.")


register("chat", () => {  
    firstmoveticks = 0 
    firstmovetickstoggle = true
}).setCriteria(/\[BOSS\] Storm: (ENERGY HEED MY CALL!|THUNDER LET ME BE YOUR CATALYST!)/)

register("chat", () => {
    stormticks = 0; instorm = true;firststormtoggle = true; overlay1.render = true
}).setCriteria("[BOSS] Storm: Pathetic Maxor, just like expected.")
 
//frst storm move 34.5s
// 27.5
// 7s 140t

register("chat", () => {
    if (!firstcrushhappened){
        firstcrushtoggle = false
        firstcrushendtime = (stormticks / 20).toFixed(2)
        stormticks = 0
        firstcrushhappened = true
        firstdpstoggle = true
    } else if (!secondcrushhappened){
        secondcrushtoggle = false
        secondcrushendtime = (stormticks / 20).toFixed(2)
        stormticks = 0
        secondcrushhappened = true
        seconddpstoggle = true
    } else {ChatLib.chat("&4why are yopu seeing thinsg")}
}).setCriteria(/\[BOSS\] Storm: (Ouch, that hurt!|Oof)/)

register("chat", () => {
    if (!firstdpshappened){
        firstdpstoggle = false
        firstdpsendtime = (stormticks / 20).toFixed(2)
        stormticks = 0
        firstdpshappened = true
        secondcrushtoggle = true
    } else {ChatLib.chat("&4why are yopu seeing this")}
}).setCriteria(/⚠ Storm is enraged! ⚠/)

register("chat", () => {
    if (!seconddpshappened){
        seconddpstoggle = false
        seconddpsendtime = (stormticks / 20).toFixed(2)
        stormticks = 0
        secondcrushhappened = true
        secondstormtoggle = true
    } else {ChatLib.chat("&4why are yopu seeing thinsg2")}
}).setCriteria(/\[BOSS\] Storm: I should have known that I stood no chance./)



register("chat", () => {
    secondstormtoggle = false
    secondstormendtime = (stormticks / 20).toFixed(2)
    instorm = false
    setTimeout(() => {
        overlay1.render = false
        overlayregister1.unregister()
    }, 5000);
}).setCriteria("[BOSS] Goldor: Who dares trespass into my domain?")

register("chat", () => {
    lightningTicks = 0
    stormlightningtoggle1 = false
    stormlightningtoggle2 = true
}).setCriteria(/\[BOSS\] Storm: (ENERGY HEED MY CALL|THUNDER LET ME BE YOUR CATALYST)!/)






register("command", () =>{
    ChatLib.chat(
`&a${stormreport[1]}
&6${stormreport[2]}
&c${stormreport[3]}
&6${stormreport[4]}
&c${stormreport[5]}
&a${stormreport[6]}`)
}).setName("stormreport")


// MAXOR
/* Intro Dialogue
[BOSS] Maxor: WELL WELL WELL LOOK WHO'S HERE!
[BOSS] Maxor: I'VE BEEN TOLD I COULD HAVE A BIT OF FUN WITH YOU.
[BOSS] Maxor: DON'T DISAPPOINT ME, I HAVEN'T HAD A GOOD FIGHT IN A WHILE.
*/

/* Stunned by laser
[BOSS] Maxor: YOU TRICKED ME!
[BOSS] Maxor: THAT BEAM! IT HURTS! IT HURTS!!
*/

/* Enraged
⚠ Maxor is enraged! ⚠
*/

/* Maxor used a special attack
[BOSS] Maxor: Eat Wither Skulls, scum!
[BOSS] Maxor: How about you taste some rapid fire Wither Skulls!
[BOSS] Maxor: Time for me to blast you away for good!
*/

/* Maxor killed
[BOSS] Maxor: I'M TOO YOUNG TO DIE AGAIN!
[BOSS] Maxor: I'LL MAKE YOU REMEMBER MY DEATH!!
*/



/* Run failed
[BOSS] Maxor: FINALLY! This took way too long.
[BOSS] Maxor: Now that you're a Ghost, can you help me clean up?
*/

/* "Random Messages"
[BOSS] Maxor: YOUR WEAPONS CAN'T PIERCE THROUGH MY SHIELD!
[BOSS] Maxor: I HOPE YOU LIKE EXPLOSIONS TOO!
[BOSS] Maxor: MY MINIONS WILL HAVE TO WIPE THE FLOOR AFTER I'M DONE WITH YOU ALL!
[BOSS] Maxor: YOUR MOBILITY TRICKS DON'T WORK IN MY DOMAIN!
*/





// STORM
/* Intro Dialogue
[BOSS] Storm: Pathetic Maxor, just like expected.
[BOSS] Storm: Don't boast about beating this simple minded Wither.
[BOSS] Storm: My abilities are unparalleled, in many ways I am the last bastion.
[BOSS] Storm: The memory of your death will be your fondest, focus up!
[BOSS] Storm: The power of lightning is quite phenomenal. A single strike can vapourise a person whole.
[BOSS] Storm: I'd be happy to show you what that's like!
*/

/* Lightning
[BOSS] Storm: ENERGY HEED MY CALL!
[BOSS] Storm: THUNDER LET ME BE YOUR CATALYST!
*/

/* Storm crushed
[BOSS] Storm: Ouch, that hurt!
[BOSS] Storm: Oof
*/

/* Ability to damage over
[BOSS] Storm: THAT WAS ONLY IN MY WAY!
[BOSS] Storm: Slowing me down will be your greatest accomplishment!
[BOSS] Storm: This factory is too small for me!
*/

/* Storm killed
[BOSS] Storm: I should have known that I stood no chance.
[BOSS] Storm: At least my son died by your hands.
*/



/* Someone died to lightning
[BOSS] Storm: Fool, I'd hide under something next time if I were you!
[BOSS] Storm: Foolish, a broken pillar won't provide you any cover!
*/

/* Storm locked
[BOSS] Storm: Bahahaha! Not a single intact pillar remains!
[BOSS] Storm: Rejoice, your last moments are with me and my lightning.
*/

/* Run failed
[BOSS] Storm: FINALLY! This took way too long.
[BOSS] Storm: Now that you're a Ghost, can you help me clean up?
*/

/* "Random Messages"
[BOSS] Storm: The Age of Men is over, we are creating tens, hundreds of withers!!
[BOSS] Storm: Not just your land, but every kingdom will soon be ruled by our army of undead!
[BOSS] Storm: No more adventurers, no more heroes, death and thunder!
[BOSS] Storm: The days are numbered until I am finally unleashed again on the world!
*/

register("command", () =>{
    ChatLib.chat(Scoreboard.getScores())
    ChatLib.chat(Scoreboard.getScoreboardTitle())
    ChatLib.chat(Scoreboard.getTitle())
}).setName("scoreboardlist")

register('command', () => {
    const lines = Scoreboard.getLines(false);
    lines.map((line) => {
        if ((line.getName().removeFormatting().replace(/[^\x00-\x7F]/g, "")).includes("Time Elapsed")) {
            ChatLib.chat(`yesss`)
        }
    });
}).setCommandName('scc');

// register("step", () => {
//     const lines = Scoreboard.getLines(false);
//     lines.map((line) => {
//         if ((line.getName().removeFormatting().replace(/[^\x00-\x7F]/g, "")).includes("Time Elapsed")) {
//             ChatLib.chat(`yesss`)
//         }
//     });
// }).setFps(100)