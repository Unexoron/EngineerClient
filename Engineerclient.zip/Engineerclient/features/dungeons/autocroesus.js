const S2DPacketOpenWindow = Java.type("net.minecraft.network.play.server.S2DPacketOpenWindow");
let rightClick = new KeyBind(Client.getMinecraft().field_71474_y.field_74313_G)


import Settings from "../../config"

let unopenedchest
let foundachest = false
let foundgooditem = false
let itemlocation 
let woodchestslot
let itemstodrop = []

register("worldLoad", () =>{
    itemstosell = []
    itemstodrop = []
})


register("packetReceived", () => {
    if (!Settings.croesustoggle) return
    Client.scheduleTask(0, ()=>{
        if (Player.getContainer().getName().includes("Croesus")) {
            setTimeout(() => {
                opencroesuscode()
            const items = Player.getContainer().getItems()
            for (let i = 0; i < 54; i++) {
                let currentitem = items[i]
                let item = (currentitem.getName()).removeFormatting().toLowerCase()
                let lore = currentitem.getLore()
                // checkinglorelegnghth = lore[lore.length - 4]
                // ChatLib.chat(checkinglorelegnghth)
                
                for (let i = 0; i < lore.length; i++) {
                    checkinglorelegnghth = lore[i]
                    if (checkinglorelegnghth.removeFormatting().toLowerCase().includes("no chests opened!")) {
                        foundachest = true
                        continue
                    }
                }
                if (foundachest) {
                    return unopenedchest = i
                }
            } 
            }, 100);
        } 
        if (Player.getContainer().getName().includes("The Catacombs - ")) {
            openchestcode()
            const items = Player.getContainer().getItems()
            for (let i = 0; i < 17; i++) {
                let currentitem = items[i]
                let item = (currentitem.getName()).removeFormatting().toLowerCase()
                if (item == "wood chest"){
                    woodchestslot = i
                }
                let lore = currentitem.getLore()
                // checkinglorelegnghth = lore[lore.length - 4]
                // ChatLib.chat(checkinglorelegnghth)
                
                for (let i = 0; i < lore.length; i++) {
                    checkinglorelegnghth = lore[i]
                    const gooditems = [
                        "fuming potato book",
                        "implosion",
                        "wither shield",
                        "shadow warp",
                        "handle",]
                    if (gooditems.some(item => checkinglorelegnghth.removeFormatting().toLowerCase().includes(item))) {
                        foundgooditem = true
                        continue
                    }
                    //if (Settings.buyrecombs){
                        if (checkinglorelegnghth.removeFormatting().toLowerCase().includes("recombobulator")){
                            foundgooditem = true
                            continue
                        }
                    //}
                }
                if (foundgooditem) {
                    return itemlocation = i
                }
            }
        } 
        if (Player.getContainer().getName().includes("Bazaar") && Settings.autosell && autoselltime) {
            if (bazaaropen) return
            bazaaropen = true
            runsellcode()
            const items = Player.getContainer().getItems()
            const listofsellingitems = [
            "wisdom",
            "recombobulator 3000",
            "fuming potato book",
            "implosion",
            "wither shield",
            "shadow warp",]

            for (let i = 53; i < 89; i++) {
                let currentitem = items[i]
                if (!currentitem) continue
                if (currentitem.getName().removeFormatting().toLowerCase().includes("enchanted book")){
                    let lore = currentitem.getLore();
                    if (listofsellingitems.some(item => lore[1].removeFormatting().toLowerCase().includes(item))) {
                        itemstosell.push(i)
                    }
                } 
                if (listofsellingitems.some(item => (currentitem.getName()).removeFormatting().toLowerCase().includes(item))) {
                    itemstosell.push(i)
                } 
            }
        } 
    })//79     26
}).setFilteredClass(S2DPacketOpenWindow) // thanks fortnite


let skipcooldown = false
let allchestcooldown = false
let autoselltime = false
let bazaaropen = false
function opencroesuscode(){
    setTimeout(() => {
        if (foundachest){
            Player.getContainer().click(unopenedchest)
            foundachest = false
        } else {
            ChatLib.chat(`\n  &a&l  Claimed all chests!\n`)
            if (!allchestcooldown) {
                Client.currentGui.close()
                autoselltime = true
                setTimeout(() => { if (Settings.autosell) {
                    let pleaseopenbznow = false
                    const items = Player.getContainer().getItems()
                    const listofsellingitems = [
                    "wisdom",
                    "recombobulator 3000",
                    "fuming potato book",
                    "implosion",
                    "wither shield",
                    "shadow warp",]
                    for (let i = 9; i < 34; i++) {
                        let currentitem = items[i]
                        if (!currentitem) continue
                        if (currentitem.getName().removeFormatting().toLowerCase().includes("enchanted book")){
                            let lore = currentitem.getLore();
                            if (listofsellingitems.some(item => lore[1].removeFormatting().toLowerCase().includes(item))) {
                                pleaseopenbznow = true
                            }
                        } 
                        if (listofsellingitems.some(item => (currentitem.getName()).removeFormatting().toLowerCase().includes(item))) {
                            pleaseopenbznow = true
                        } 
                    }
                    if (pleaseopenbznow) ChatLib.command("bz")
                    else {rundropcode()}
                } 
            }, 300);
                setTimeout(() => {autoselltime = false}, 3000);
            }

            allchestcooldown = true
            setTimeout(() => {
                allchestcooldown = false
            }, 4000);
        }
    }, 300);
}

function openchestcode(){
    const items = Player.getContainer().getItems()
    const listofsellingitems = [
    "wisdom",
    "last stand",
    "ultimate wise",
    "one for all",
    "soul eater",
    "recombobulator 3000",
    "fuming potato book",
    "implosion",
    "wither shield",
    "shadow warp",]

    for (let i = 53; i < 89; i++) {
        let currentitem = items[i]
        if (!currentitem) continue
        if (currentitem.getName().removeFormatting().toLowerCase().includes("enchanted book")){
            let lore = currentitem.getLore();
            if (listofsellingitems.some(item => lore[1].removeFormatting().toLowerCase().includes(item))) {
                itemstosell.push(i)
            }
        } 
        if (listofsellingitems.some(item => (currentitem.getName()).removeFormatting().toLowerCase().includes(item))) {
            itemstosell.push(i)
        } 
    }

    setTimeout(() => {
        if (foundgooditem){
            Player.getContainer().click(itemlocation)
            setTimeout(() => Player.getContainer().click(31), 150);
            setTimeout(() => rightClick.setState(true), 450);
            setTimeout(() => rightClick.setState(false), 550);
            foundgooditem = false
        } else {
            Player.getContainer().click(woodchestslot)
            setTimeout(() => Player.getContainer().click(31), 150);
            setTimeout(() => rightClick.setState(true), 450);
            setTimeout(() => rightClick.setState(false), 550);
        }
    }, 100);
}

function runsellcode(){
    setTimeout(() => {
        function sellintitems(){
            ChatLib.chat("&6itmes left to sell&7: " + itemstosell.length)
            if (itemstosell.length == 0) {
                Client.currentGui.close()
                setTimeout(() => {bazaaropen = false}, 500);
                setTimeout(() => {rundropcode()}, 200);
                return 
            }
            setTimeout(() => {Player.getContainer().click(itemstosell[0])
                itemstosell.shift()}, 200);
            setTimeout(() => {Player.getContainer().click(11)}, 450);
            setTimeout(() => {Player.getContainer().click(31)}, 600);
            setTimeout(() => sellintitems(), 650);
        } 
        sellintitems()
    }, 200);
}
// 8 43
// last slot index 53

let haditems = false

function rundropcode(){
    const items = Player.getContainer().getItems()
    const listofdropingitems = [
    "maxor the fish",
    "feather falling vi",
    "rejuvenate i",
    "bank i",
    "combo i",
    "infinite quiver vi"]
    // Your inventory is full!
    for (let i = 9; i < 34; i++) {
        let currentitem = items[i]
        if (!currentitem) continue
        if (currentitem.getName().removeFormatting().toLowerCase().includes("enchanted book")){
            let lore = currentitem.getLore();
            if (listofdropingitems.some(item => lore[1].removeFormatting().toLowerCase().includes(item))) {
                //if (i !== Settings.inventoryslot - 1) {
                    itemstodrop.push(i)
                    haditems = true
                //}
            }
        } 
        if (listofdropingitems.some(item => (currentitem.getName()).removeFormatting().toLowerCase().includes(item))) {
            //if (i !== Settings.inventoryslot - 1) {
                itemstodrop.push(i)
                haditems = true
            //} else {
            //    ChatLib.chat(i)
            //}
        } 
    }

    setTimeout(() => {
        if (itemstodrop.length == 0) {
            Client.currentGui.close()
            skipcooldown = false
            return finaldropcode()
            
        }
        Client.currentGui.close()
        if (!skipcooldown){
            ChatLib.chat("\n&c&l              dropping items in 2s\n           &r&6hold out an empty hotbar slot 1\n")
            setTimeout(() => ChatLib.chat("\n&c&l              dropping items in 1s\n           &r&6hold out an empty hotbar slot 1\n"), 1000);

            setTimeout(() => {

                Player.getContainer().click(36 + Player.getHeldItemIndex())
                setTimeout(() => {
                    Player.getContainer().click(Settings.inventoryslot + 8)
                }, 150);
                setTimeout(() => {
                    Player.getContainer().click(36 + Player.getHeldItemIndex())
                }, 300);
                setTimeout(() => {
                    Player.asPlayerMP().player.func_71040_bB(true)
                }, 450);
                setTimeout(() => {
                    Player.asPlayerMP().player.func_71040_bB(true)
                }, 500);

                setTimeout(() => {
                    function dropintitems(){
                        if (itemstodrop.length == 0) {return setTimeout(() => rundropcode(), 100);}
                        setTimeout(() => {
                            ChatLib.chat("&6itmes left&7: " + itemstodrop.length)
                            Player.getContainer().click(itemstodrop[0])
                            setTimeout(() => {
                                Player.getContainer().click(36 + Player.getHeldItemIndex())
                            }, 150);
                            setTimeout(() => {
                                Player.asPlayerMP().player.func_71040_bB(true)
                            }, 250);
                            setTimeout(() => {
                                Player.asPlayerMP().player.func_71040_bB(true)
                            }, 300);
                            itemstodrop.shift()
                        }, 100);
                        setTimeout(() => dropintitems(), 400);
                    } 
                    dropintitems()
                }, 700);
            }, 2000);
        }
        if (skipcooldown){
            setTimeout(() => {
                function dropintitems(){
                    if (itemstodrop.length == 0) {return setTimeout(() => rundropcode(), 100)}
                    setTimeout(() => {
                        ChatLib.chat("&6itmes left&7: " + itemstodrop.length)
                        Player.getContainer().click(itemstodrop[0])
                        setTimeout(() => {
                            Player.getContainer().click(36 + Player.getHeldItemIndex())
                        }, 150);
                        setTimeout(() => {
                            Player.asPlayerMP().player.func_71040_bB(true)
                        }, 250);
                        setTimeout(() => {
                            Player.asPlayerMP().player.func_71040_bB(true)
                        }, 300);
                        itemstodrop.shift()
                    }, 100);
                    setTimeout(() => dropintitems(), 400);
                } 
                dropintitems()
            }, 200);
        }
        skipcooldown = true
    }, 100);
}

function finaldropcode(){
    if (!haditems) return
    haditems = false
    setTimeout(() => {
        Player.getContainer().click(Settings.inventoryslot + 8)
        setTimeout(() => {
            Player.getContainer().click(36 + Player.getHeldItemIndex())
             ChatLib.chat("\n           &a&l done!\n")
        }, 350);
    }, 200);

}

register("command", () =>{
    setTimeout(() => Player.getContainer().click(51), 150);
    setTimeout(() => Player.getContainer().click(34), 300);
}).setName("EngineerAutoCroesustest")

register("command", () =>{
    ChatLib.chat(Player.getHeldItemIndex())
    ChatLib.chat(`&aEngineerAutoCroesus is working!`)
}).setName("EngineerAutoCroesus")



register("command", () =>{
    let nguwijsreb = Date.now()
    ChatLib.chat(nguwijsreb - Date.now())
    setTimeout(() => {
        ChatLib.chat(nguwijsreb - Date.now())
    }, 0);
}).setName("bvuisdbviuer")

register("command", () =>{
    rundropcode()
}).setName("drop")

register("command", () =>{
    runsellcode()
}).setName("sell")


