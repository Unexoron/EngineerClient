let chatMessages = [];

register("chat", (message, event) => {
    const formatted = ChatLib.getChatMessage(event, true);
    if (typeof formatted === 'string') {
        chatMessages.push(formatted);
    } else {
        ChatLib.chat("Failed to capture message with formatting.");
    }
}).setCriteria("${message}");

function searchChatMessages(query) {
    let results = [];
    
    if (typeof query !== 'string') {
        ChatLib.chat("&cInvalid search query.");
        return;
    }
    
    query = query.toLowerCase().trim();

    if (query.length === 0) {
        ChatLib.chat("&cEmpty search query.");
        return;
    }

    ChatLib.chat("&3Searching for: " + "&e" + query);

    for (let i = 0; i < chatMessages.length; i++) {
        let msg = chatMessages[i];
        if (typeof msg === 'string') {
            let msgLower = msg.toLowerCase();

            if ((msgLower).includes(query)) {
                results.push(msg);
            }
        }
    }

    if (results.length === 0) {
        ChatLib.chat("&cNo messages found matching your search.");
    } else {
        ChatLib.chat("&aSearch Results:");
        ChatLib.chat(ChatLib.getChatBreak("&a-"))
        for (let j = 0; j < results.length; j++) {
            ChatLib.chat(" &f| " + results[j]);
        }
        ChatLib.chat(ChatLib.getChatBreak("&a-"))
    }
}

register("command", (...args) => {
    const query = args.join(" ");
    searchChatMessages(query);
}).setName("search");

register("command", () => {
    ChatLib.chat("Stored Messages:");
    for (let i = 0; i < chatMessages.length; i++) {
        ChatLib.chat(chatMessages[i]);
        ChatLib.chat("Debug: Displaying stored message " + (i + 1));
    }
}).setName("messagelist");
