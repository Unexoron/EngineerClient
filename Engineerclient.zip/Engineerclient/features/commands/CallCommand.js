/// <reference types="../../../CTAutocomplete" />

const A = new Message(
    new TextComponent("&a&lA&f: &fi4 &f+ &f&l[&e&lE&f&l] &f+ &f(1) &f+ &1&f&l[&c&lC&f&l] &f+ &6{2} &f&l│ &f1 &f+ &f(3) &f+ &f&l[&d&lD&f&l] &f&l│ &f2 &f+ &f&l[&b&lB&f&l] &f&l│ &fBl").setClick("run_command", "/call a").setHoverValue("&eClick to Call")
);
const B = new Message(
    new TextComponent("&b&lB&f: &fSS &f+ &1&f&l[&a&lA&f&l] &f&l│ &f2 &f&l│ &6{Core} &f&l│ &f3").setClick("run_command", "/call b").setHoverValue("&eClick to Call")
);
const C = new Message(
    new TextComponent("&c&lC&f: &fi3 &f+ &f&l[&d&lD&f&l] &f+ &fBl &f+ &fee2 &f+ &ffi2 &f&l│&r  &f4 &f+ &fRl &f+ &f&l[&d&lD&f&l] &f&l│&r &f4 &f+ &fBl &f+ &f&l[&d&lD&f&l] &f&l│&r &f1").setClick("run_command", "/call c").setHoverValue("&eClick to Call")
);
const D = new Message(
    new TextComponent("&d&lD&f: &f2 &f+ &f1 &f+ &1&f&l[&c&lC&f&l] &f&l│ &fLl &f+ &fee3 &f&l│ &f3 &f+ &f&l[&b&lB&f&l] &f&l│ &f2").setClick("run_command", "/call d").setHoverValue("&eClick to Call")
);
const E = new Message(
    new TextComponent("&e&lE&f: &f4 &f+ &f3 &f+ &1&f&l[&c&lC&f&l] &f&l│ &f5 &f+ &f(3) &f+ &f&l[&d&lD&f&l] &f&l│ &f1 &f+ &f&l[&b&lB&f&l] &f&l│ &f4").setClick("run_command", "/call e").setHoverValue("&eClick to Call")
);

const callsList = [
    "A: i4 + [E] + (1) + [C] + {2} │ 1 + (3) + [D] │ 2 + [B] │ Bl",
    "B: SS + [A] │ 2 │ {Core} │ 3",
    "C: i3 + [D] + Bl + ee2 + fi2 │  4 + Rl + [D] │ 4 + Bl + [D] │ 1",
    "D: 2 + 1 + [C] │ Ll + ee3 │ 3 + [B] │ 2",
    "E: 4 + 3 + [C] │ 5 + (3) + [D] │ 1 + [B] │ 4"
    ]

const pclist = new Thread(() => {
    for(var i = 0; i < callsList.length; i++){
    ChatLib.command("pc " + callsList[i])
    pclist.sleep(250)
    }
})

register("command", (Call) => {
        if (Call.toLowerCase() == "a"){
            ChatLib.command("pc " + callsList[0]);
        }
        if (Call.toLowerCase() == "b"){
            ChatLib.command("pc " + callsList[1]);
        }
        if (Call.toLowerCase() == "c"){
            ChatLib.command("pc " + callsList[2]);
        }
        if (Call.toLowerCase() == "d"){
            ChatLib.command("pc " + callsList[3]);
        }
        if (Call.toLowerCase() == "e"){
            ChatLib.command("pc " + callsList[4]);
        }
        if (Call == "list" || Call == "l"){
            ChatLib.chat(A);
            ChatLib.chat(B);
            ChatLib.chat(C);
            ChatLib.chat(D);
            ChatLib.chat(E);
        }
        if (Call == "pclist" || Call == "pcl"){
            pclist.start();
        }
        if (Call.toLowerCase() == "andrew"){
            ChatLib.command("pc Lc / Purple Pad /  Both levers + Early Enter 2 ➩ 4 + Right lever ➩ 4 ➩ 4");
        }
        if (Call.toLowerCase() == "coffee"){
            ChatLib.command("pc i4 ➩ 1(3) ➩ 1 ➩ 1");
        }
        if (Call.toLowerCase() == "paper" || Call.toLowerCase() == "opaper"){
            ChatLib.command("pc Both Levers + Early Enter 2 ➩ 4 + Right Lever ➩ 4 ➩ 4");
        }
        if (!Call){
            prefix("&cUsage: /call <a, b, c, d, e, list, pclist, andrew, coffee, paper>");
        }
}).setName("call").setAliases("c").setTabCompletions("a", "b", "c", "d", "e", "list", "pclist", "andrew", "coffee", "paper")