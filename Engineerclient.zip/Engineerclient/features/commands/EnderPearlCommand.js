/// <reference types="../../../CTAutocomplete" />
import Settings from "../../config";

let NewLobby = false
let Queued = false
let Time = 0

register("command", (count) => {
    if (Queued == false) {
        if (count) {
            const num = parseInt(count)
            if (isNaN(num)) return ChatLib.chat(`&6[&4Engineer&8Client&6]&r &c/enderpearl [amount]`)
            NewLobby = true
            ChatLib.command(`gfs ender_pearl ${num}`, false)
            return
        }
        const pearlStack = Player.getInventory().getItems().find(a => a?.getName() == "§fEnder Pearl")
        if (!pearlStack) {
            NewLobby = true
            ChatLib.command(`gfs ender_pearl 16`, false)
            return
        }
        const toGive = 16 - pearlStack.getStackSize()
        if (toGive == 0) {
            if (Settings.FullEnderPearlMsg){
                ChatLib.chat("&cYou already have a full stack")
            }
        return }
        NewLobby = true
        ChatLib.command(`gfs ender_pearl ${toGive}`, false)
    }
}).setName("enderpearl").setAliases("ep")

register("chat", () => {
    if (NewLobby == true && Queued == false){
        Queued = true
        ChatLib.chat("&7Command Queued")
        World.playSound("note.pling", 4, 0.1)
        Wait4s.start();
    }
}).setCriteria(/You may only use this command after 4s on the server!/)

register("worldLoad", () => {
    Time = Date.now();
})

const Wait4s = new Thread(() => {
    let Wait = Date.now() - Time
    let TimeToWait = 4000 - Wait
    if (TimeToWait < 0) {TimeToWait = 0}
    if (TimeToWait < 1000) {TimeToWait = TimeToWait + 1200}
        Wait4s.sleep(TimeToWait)
        Queued = false
        NewLobby = false
        ChatLib.chat("&7Command Executed")
        ChatLib.command(`ep`, true)
})