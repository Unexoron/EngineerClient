/// <reference types="../../../CTAutocomplete" />

const pfA = new Message(
    new TextComponent("&a&lA&f: &fSS &f+ &f&l[&c&lC&f&l] &f&l│ &f5 &f+ &f(3) &f+ &f&l[&d&lD&f&l] &f&l│ &f3 &f+ &f&l[&b&lB&f&l] &f&l│ &f3").setClick("run_command", "/pfcall a").setHoverValue("&eClick to Call")
);
const pfB = new Message(
    new TextComponent("&b&lB&f: &fi4 &f+ &1&f&l[&c&lC&f&l] &f&l│ &f2 &f&l[&d&lD&f&l] &f&l│ &6{Core} &f&l│ &fBl").setClick("run_command", "/pfcall b").setHoverValue("&eClick to Call")
);
const pfC = new Message(
    new TextComponent("&c&lC&f: &fi3 &f+ &f&l[&d&lD&f&l] &f+ &fBl &f+ &fee2 &f&l│&r  &f4 &f+ &fRl &f+ &f&l[&d&lD&f&l] &f&l│&r &f4 &f+ &fBl &f+ &f&l[&b&lB&f&l] &f&l│&r &f4").setClick("run_command", "/pfcall c").setHoverValue("&eClick to Call")
);
const pfD = new Message(
    new TextComponent("&d&lD&f: &f4 &f+ &f3 &f+ &1&f&l[&c&lC&f&l] &f&l│ &fLl &f+ &fee3 &f&l│ &f2 &f+ &f&l[&b&lB&f&l] &f&l│ &f2").setClick("run_command", "/pfcall d").setHoverValue("&eClick to Call")
);
const pfE = new Message(
    new TextComponent("&e&lE&f: &f2 &f+ &f1 &f+ &1&f&l[&c&lC&f&l] &f&l│ &f1 &f+ &f(3) &f+ &f&l[&d&lD&f&l] &f&l│ &f1 &f+ &f&l[&b&lB&f&l] &f&l│ &f1").setClick("run_command", "/pfcall e").setHoverValue("&eClick to Call")
);

const pfCallList = [
    "A: SS + [Leap C] │ 5 + (3) + [Leap D] │ 3 + [Leap B] │ 3",
    "B: i4 + [Leap C] │ 2 + [Leap D] │ {Core} │ Bl",
    "C: i3 + [Leap D] + Bl + ee2 │ 4 + Rl + [Leap D] │ 4 + Bl + [Leap B] │ 4",
    "D: 4 + 3 + [Leap C] │ Ll + ee3 │ 2 + [Leap B] │ 2",
    "E: 2 + 1 + [Leap C] │ 1 + (3) + [Leap D] │ 1 + [Leap B] │ 1"
    ]

const pfpclist = new Thread(() => {
    for(var i = 0; i < pfCallList.length; i++){
        ChatLib.command("pc " + pfCallList[i])
        pclist.sleep(400)
    }
})

register("command", (Call) => {
        if (Call.toLowerCase() == "a"){
            ChatLib.command("pc " + pfCallList[0]);
        }
        if (Call.toLowerCase() == "b"){
            ChatLib.command("pc " + pfCallList[1]);
        }
        if (Call.toLowerCase() == "c"){
            ChatLib.command("pc " + pfCallList[2]);
        }
        if (Call.toLowerCase() == "d"){
            ChatLib.command("pc " + pfCallList[3]);
        }
        if (Call.toLowerCase() == "e"){
            ChatLib.command("pc " + pfCallList[4]);
        }
        if (Call == "list" || Call == "l"){
            ChatLib.chat(pfA);
            ChatLib.chat(pfB);
            ChatLib.chat(pfC);
            ChatLib.chat(pfD);
            ChatLib.chat(pfE);
        }
        if (Call == "pclist" || Call == "pcl"){
            pfpclist.start();
        }
        if (!Call){
            prefix("&cUsage: /pfcall <a, b, c, d, e, list, pclist>")
            return
        }
}).setName("pfcall").setAliases("pfc").setTabCompletions("a", "b", "c", "d", "e", "list", "pclist")