/// <reference types="../../../CTAutocomplete" />
import Settings from "../../config";
import { lsiw, msglsiw } from "./LowSkillInvwalkersCommand";

let name2 = "dagsd"
let ignToInv2 = "dagsd2"

register("chat", (rank, name, yapping) => {
    if (Settings.PartyCommandToggle && Settings.LsiwPartyCommand){
        lsiw.start()
    }
}).setCriteria(/Party > (\[.+\])? ?(.+) ?[ቾ⚒]?: !lsiw/)

register("chat", (rank, name, yapping) => {
    if (Settings.PartyCommandToggle && Settings.LsiwPartyCommand){
        msglsiw.start()
    }
}).setCriteria(/(From|To) (\[.+\])? ?(.+) ?[ቾ⚒]?: !lsiw/)

register('chat', (chat, rank, name, alias) => {
	if (!Settings.InvPartyCommand) return
    name2 = name
    inv1.start()
}).setCriteria(/(Party >|From) (\[.+\])? ?(.+) ?[ቾ⚒]?: !inv(ite)?/)

register('chat', (chat, rank, name, alias, ignToInv) => {
    if (!Settings.InvPartyCommand) return
    ignToInv2 = ignToInv
    inv2.start()
}).setCriteria(/(Party >|From) (\[.+\])? ?(.+) ?[ቾ⚒]?: !inv(ite)? (.+)?/)

const inv1 = new Thread(() => {
    inv1.sleep(420)
    ChatLib.command(`p ${name2}`)
    name2 = "dagsd"
})

const inv2 = new Thread(() => {
    inv2.sleep(420)
    ChatLib.command(`p ${ignToInv2}`)
    ignToInv2 = "dagsd2"
})