/// <reference types="../../../CTAutocomplete" />

let cancel = false
let nop = `1`

// nop = name of player

register("command", (LSIW, LSIW2) => {
    if (LSIW.toLowerCase() == "video"){
        space("");
        prefix("youtube.com/watch?v=dAih627fJCk");
        space("");
    }
    if (LSIW.toLowerCase() == "lyrics"){
        lsiw.start();
    }
    if (LSIW.toLowerCase() == "msglyrics"){
        if (LSIW2 == null){
            msglsiw.start();
        } else {
            nop = LSIW2;
            msglsiwname.start();
        }
    }
    if (LSIW.toLowerCase() == "cancel"){
        cancel = true
    }
    if (LSIW == "video" || LSIW == "lyrics" || LSIW == "msglyrics" || LSIW == "cancel"){
    } else {
        prefix("&cUsage: /lsiw <video, msglyrics <player>, lyrics, cancel>")
    }
}).setName("LOWSKILLINVWALKAS").setAliases("LSIW").setTabCompletions("video", "lyrics", "msglyrics", "cancel")

const arrayLyrics = ["Stepping into the danger zone", "M7, I'm on my own, low-skill invwalkers better watch out, I'm the master",
    "Gonna make you doubt", "Feeling the heat", "Adrenaline rush, Biohunt, Veso, Penny, they can hush but they can't distract me from my grind",
    "I'm here to conquer and leave them behind","All the High-skill invwalkers will take control", "Beat your terminals personal best and find your family",
    "Carried by mods is different, I could never relate", "All i can do is hate and break, Master of deception", "I'm on the floor, taking control",
    "Gonna even the score", "Low-skill invwalkers, they can't break me", "I'm the boss, I'm the one they cant see"]

export const lsiw = new Thread(() => {
    for(var i = 0; i < arrayLyrics.length; i++){
        lsiw.sleep(420)
        ChatLib.command("pc " + arrayLyrics[i])
        if (cancel){
            cancel = false
            break
        }
    }
})

export const msglsiw = new Thread(() => {
    for(var i = 0; i < arrayLyrics.length; i++){
        lsiw.sleep(800)
        ChatLib.command("r " + arrayLyrics[i])
        if (cancel){
            cancel = false
            break
        }
    }
})

const msglsiwname = new Thread(() => {
    for(var i = 0; i < arrayLyrics.length; i++){
        lsiw.sleep(800)
        ChatLib.command(`w ${nop} ` + arrayLyrics[i])
        if (cancel){
            cancel = false
            break
        }
    }
})